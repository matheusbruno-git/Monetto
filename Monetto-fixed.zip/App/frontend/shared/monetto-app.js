// monetto-app.js
// Shared helpers used across the school-admin pages: session access, logout,
// and loading the school-admin dashboard summary.

function getSession() {
  try {
    return JSON.parse(localStorage.getItem('session') || 'null');
  } catch (err) {
    console.warn('Sessão inválida no localStorage, limpando.', err);
    localStorage.removeItem('session');
    return null;
  }
}

// Several pages call sairDaConta(destino) directly from an onclick and expect
// this file to provide it.
function sairDaConta(destino) {
  if (confirm('Tem certeza que deseja sair da conta?')) {
    localStorage.removeItem('session');
    window.location.href = destino || '../../user/login-principal/login-principal.html';
  }
}

async function carregarDashboardAdminEscolar() {
  try {
    if (!window.api || typeof window.api.getDashboardAdminEscolar !== 'function') {
      console.warn('API getDashboardAdminEscolar não disponível');
      return;
    }

    const session = getSession();
    if (!session || !session.id) {
      console.warn('Nenhuma sessão ativa — faça login novamente.');
      return;
    }

    const result = await window.api.getDashboardAdminEscolar(session.id);
    if (!result.success) {
      console.warn('Erro do backend:', result.message);
      return;
    }

    const d = result.data;

    // Nome da escola
    const elSchool = document.getElementById('school-name');
    if (elSchool) elSchool.textContent = d.school.name;

    // Hero counters  →  d.school.stats
    const elAlunos = document.getElementById('alunos-count');
    if (elAlunos) elAlunos.textContent = d.school.stats[0].value;      // Alunos

    const elDeactivatedAlunos = document.getElementById('deactivated-alunos-count');
    if (elDeactivatedAlunos) elDeactivatedAlunos.textContent = d.stats[4]?.value || '0'; // Alunos inativos +7 dias

    const elCompletionRate = document.getElementById('completion-rate');
    if (elCompletionRate) elCompletionRate.textContent = d.stats[1]?.value || '0'; // Taxa de conclusão

    const elXpDistributed = document.getElementById('xp-distributed');
    if (elXpDistributed) elXpDistributed.textContent = d.stats[3]?.value || '0'; // XP distribuído

    const elProf = document.getElementById('professores-count');
    if (elProf) elProf.textContent = d.school.stats[1].value;          // Professores

    const elTurmas = document.getElementById('turmas-count');
    if (elTurmas) elTurmas.textContent = d.school.stats[2].value;       // Turmas

    // Cards de stats  →  d.stats
    const elMatric = document.getElementById('alunos-matriculados-count');
    if (elMatric) elMatric.textContent = d.stats[0].value;              // Alunos matriculados

    const elTarefas = document.getElementById('tarefas-count');
    if (elTarefas) elTarefas.textContent = d.stats[2].value;            // Tarefas

    const elXp = document.getElementById('xp-count');
    if (elXp) elXp.textContent = d.stats[3].value;                      // XP

  } catch (err) {
    console.error('Erro ao carregar dashboard:', err);
  }
}

function iniciarMonetto() {
  const session = getSession();

  // Fill in any ".admin-nome/.user-nome/.topbar-nome" elements and let pages
  // listen for this if they want the logged-in user's data.
  document.dispatchEvent(new CustomEvent('monetto:ready', { detail: { usuario: session || {} } }));

  carregarDashboardAdminEscolar();
}

// Roda quando a página carregar
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', iniciarMonetto);
} else {
  iniciarMonetto();
}
