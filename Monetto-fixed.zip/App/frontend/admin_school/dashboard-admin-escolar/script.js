(() => {
  const container = document.getElementById("sidebar-container");
  if (!container) return;

  const sidebar = "../../Assets/Components/admin-school-sidebar.html";

  fetch(sidebar, { cache: "no-store" })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`Failed to load sidebar: ${response.status}`);
      }
      return response.text();
    })
    .then((html) => {
      container.innerHTML = html;
    })
    .catch((err) => {
      console.error(err);
    });
})();

// NOTE: loading the actual dashboard numbers (school name, alunos-count, etc.)
// is handled by ../../shared/monetto-app.js, which this page includes directly.
// This file used to duplicate that with a broken top-level `await` — removed.
