function sairDaConta(destino) {
  if (confirm('Tem certeza que deseja sair da conta?')) {
    localStorage.removeItem('session');
    window.location.href = destino;
  }
}

document.getElementById("btn").addEventListener("click", async () => {
  const msgEl = document.getElementById("msg");
  const session = JSON.parse(localStorage.getItem('session') || 'null');

  if (!session || !session.id_escola) {
    msgEl.textContent = "Sessão inválida — faça login novamente.";
    msgEl.style.color = "red";
    return;
  }

  const dados = {
    id_escola: session.id_escola,
    nome: document.getElementById("nome").value,
    data_nascimento: document.getElementById("data").value,
    cpf: document.getElementById("cpf").value,
    telefone: document.getElementById("tel").value,
    email: document.getElementById("email").value,
    foto_url: document.getElementById("foto")?.value || null
  };

  const result = await window.api.registerProfessor(dados);

  msgEl.textContent = result.success
    ? `${result.message}${result.senhaTemporaria ? ` Senha temporária: ${result.senhaTemporaria}` : ''}`
    : result.message;
  msgEl.style.color = result.success ? "green" : "red";

  if (result.success) {
    ["nome", "data", "cpf", "tel", "email"].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = "";
    });
  }
});

(() => {
  const container = document.getElementById("sidebar-container");
  if (!container) return;

  const sidebar = "../../Assets/Components/admin-school-sidebar.html";

  fetch(sidebar, { cache: "no-store" })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`Failed to load sidebar: ${response.status}`);
      }
      return response.text();
    })
    .then((html) => {
      container.innerHTML = html;
    })
    .catch((err) => {
      console.error(err);
    });
})();
