// backend/create_aluno.js
const db = require("./connection.js");
const bcrypt = require("bcryptjs");

async function registerAluno(dados) {
  try {
    if (!dados.nome || !dados.id_escola) {
      return { success: false, message: "Nome e escola são obrigatórios." };
    }

    // Alunos don't pick their own password at registration time, so we generate
    // a temporary one (a real "forgot password" flow can replace this later).
    const senhaTemporaria = Math.random().toString(36).slice(-8);
    const senha_hash = await bcrypt.hash(senhaTemporaria, 10);

    // Students may not have an email of their own yet — fall back to the
    // responsible party's email so the UNIQUE(email) constraint still works,
    // or a placeholder if neither is available.
    const email = dados.email || dados.email_responsavel || null;

    const sql = `
      INSERT INTO usuarios
      (id_perfil, id_escola, nome, email, senha_hash, data_nascimento, cpf,
       responsavel, telefone_responsavel, email_responsavel, serie, ativo)
      VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    `;

    const [result] = await db
      .promise()
      .execute(sql, [
        dados.id_escola,
        dados.nome,
        email,
        senha_hash,
        dados.data_nascimento || null,
        dados.cpf || null,
        dados.responsavel || null,
        dados.telefone_responsavel || null,
        dados.email_responsavel || null,
        dados.serie || null,
      ]);

    return {
      success: true,
      message: "Aluno cadastrado com sucesso!",
      id: result.insertId,
      senhaTemporaria,
    };
  } catch (err) {
    console.error(err);
    if (err.code === 'ER_DUP_ENTRY') {
      return { success: false, message: "Já existe um aluno cadastrado com esse email/CPF." };
    }
    return { success: false, message: "Erro ao cadastrar aluno." };
  }
}

module.exports = { registerAluno };
