// backend/create_professor.js
const db = require("./connection.js");
const bcrypt = require("bcryptjs");

async function registerProfessor(dados) {
  try {
    if (!dados.nome || !dados.email || !dados.id_escola) {
      return { success: false, message: "Nome, email e escola são obrigatórios." };
    }

    // The admin form doesn't collect a password for new teachers, so generate
    // a temporary one — same pattern used for students.
    const senhaTemporaria = Math.random().toString(36).slice(-8);
    const senha_hash = await bcrypt.hash(senhaTemporaria, 10);

    const sql = `
      INSERT INTO usuarios
      (id_perfil, id_escola, nome, email, senha_hash, cpf, data_nascimento, telefone, foto_url, ativo)
      VALUES (2, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    `;

    const [result] = await db
      .promise()
      .execute(sql, [
        dados.id_escola,
        dados.nome,
        dados.email,
        senha_hash,
        dados.cpf || null,
        dados.data_nascimento || null,
        dados.telefone || null,
        dados.foto_url || null,
      ]);

    return {
      success: true,
      message: "Professor cadastrado com sucesso!",
      id: result.insertId,
      senhaTemporaria,
    };
  } catch (err) {
    console.error(err);
    if (err.code === 'ER_DUP_ENTRY') {
      return { success: false, message: "Já existe um professor cadastrado com esse email/CPF." };
    }
    return { success: false, message: "Erro ao cadastrar professor." };
  }
}

module.exports = { registerProfessor };
