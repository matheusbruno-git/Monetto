// backend/create_user.js
const db = require("./connection.js");
const bcrypt = require("bcryptjs");

async function registerUser(dados) {
  try {
    console.log("📝 Tentando cadastrar usuário:", dados.email);

    if (!dados.nome || !dados.email || !dados.senha || !dados.id_perfil) {
      return { success: false, message: "Todos os campos são obrigatórios." };
    }

    // Check if email already exists
    const [existing] = await db
      .promise()
      .execute("SELECT id_usuario FROM usuarios WHERE email = ?", [
        dados.email,
      ]);

    if (existing.length > 0) {
      return { success: false, message: "Este email já está cadastrado." };
    }

    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const senha_hash = await bcrypt.hash(dados.senha, salt);

    // id_usuario is AUTO_INCREMENT in the schema, so we don't (and shouldn't) supply it
    const sql = `
      INSERT INTO usuarios 
      (id_perfil, id_escola, nome, email, senha_hash, ativo, criado_em)
      VALUES (?, ?, ?, ?, ?, 1, NOW())
    `;

    const [result] = await db
      .promise()
      .execute(sql, [
        dados.id_perfil,
        dados.id_escola || null,
        dados.nome,
        dados.email,
        senha_hash,
      ]);

    console.log("✅ Usuário criado com sucesso!");

    return {
      success: true,
      message: "Conta criada com sucesso! Você já pode fazer login.",
      id: result.insertId,
    };
  } catch (err) {
    console.error("❌ ERRO AO CADASTRAR:", err);
    return {
      success: false,
      message: "Erro ao criar conta. Tente novamente.",
    };
  }
}

module.exports = { registerUser };
