// ============================================================
//  MONETTO — frontend/api.js
//  Cliente HTTP para conectar cada tela ao backend
//  Copie este arquivo para o projeto Electron/frontend
//  e importe nas páginas conforme necessário
// ============================================================

const BASE_URL = window.MONETTO_API_URL || 'http://localhost:3001/api/v1';

// ─── STORE LOCAL DE TOKEN ───────────────────────────────────
// Nunca salve o accessToken em localStorage em produção real.
// Aqui usamos memória (variável) — o refresh token fica em cookie httpOnly.
let _accessToken = null;

function setToken(t)  { _accessToken = t; }
function getToken()   { return _accessToken; }
function clearToken() { _accessToken = null; }

// ─── FETCH COM AUTH AUTOMÁTICO + RETRY ──────────────────────
async function api(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (getToken()) headers['Authorization'] = `Bearer ${getToken()}`;

  const res = await fetch(`${BASE_URL}${path}`, {
    credentials: 'include',   // envia o cookie refresh_token
    ...options,
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  // Token expirado → tenta renovar uma vez
  if (res.status === 401 && !options._retry) {
    const renovado = await renovarToken();
    if (renovado) {
      return api(path, { ...options, _retry: true });
    } else {
      // Sessão encerrada — redireciona para login
      clearToken();
      window.location.href = '../login-principal/login-principal.html';
      return;
    }
  }

  if (!res.ok) {
    const erro = await res.json().catch(() => ({ erro: 'Erro desconhecido' }));
    throw Object.assign(new Error(erro.erro || 'Erro na API'), { status: res.status });
  }

  // 204 No Content
  if (res.status === 204) return null;
  return res.json();
}

// Helpers por método HTTP
const get    = (path, opts = {})        => api(path, { method: 'GET', ...opts });
const post   = (path, body, opts = {})  => api(path, { method: 'POST', body, ...opts });
const put    = (path, body, opts = {})  => api(path, { method: 'PUT', body, ...opts });
const patch  = (path, body, opts = {})  => api(path, { method: 'PATCH', body, ...opts });
const del    = (path, opts = {})        => api(path, { method: 'DELETE', ...opts });

// ─── RENOVAR TOKEN (silencioso) ─────────────────────────────
async function renovarToken() {
  try {
    const data = await fetch(`${BASE_URL}/auth/refresh`, {
      method: 'POST', credentials: 'include',
    }).then(r => r.ok ? r.json() : null);
    if (data?.accessToken) { setToken(data.accessToken); return true; }
    return false;
  } catch { return false; }
}

// ════════════════════════════════════════════════════════════
// ════ AUTH ══════════════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const Auth = {
  async login(email, senha) {
    const data = await post('/auth/login', { email, senha });
    setToken(data.accessToken);
    // Salva dados básicos do usuário (sem dados sensíveis)
    sessionStorage.setItem('monetto_usuario', JSON.stringify(data.usuario));
    return data.usuario;
  },

  async logout() {
    try { await post('/auth/logout'); } catch {}
    clearToken();
    sessionStorage.removeItem('monetto_usuario');
    window.location.href = '../login-principal/login-principal.html';
  },

  getUsuarioLocal() {
    try {
      return JSON.parse(sessionStorage.getItem('monetto_usuario'));
    } catch { return null; }
  },

  // Verifica se está logado ao abrir qualquer página protegida
  async verificarSessao() {
    if (!getToken()) {
      const renovado = await renovarToken();
      if (!renovado) {
        window.location.href = '../login-principal/login-principal.html';
        return null;
      }
    }
    return Auth.getUsuarioLocal();
  },
};

// ════════════════════════════════════════════════════════════
// ════ DASHBOARD ALUNO ═══════════════════════════════════════
// ════════════════════════════════════════════════════════════
const DashboardAluno = {
  buscarResumo:    () => get('/aluno/dashboard'),
};

// ════════════════════════════════════════════════════════════
// ════ PERFIL ALUNO ══════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const PerfilAluno = {
  buscar:           ()      => get('/aluno/perfil'),
  atualizar:        (dados) => put('/aluno/perfil', dados),
  rankingTurma:     (turmaId) => get(`/aluno/ranking/${turmaId}`),
};

// ════════════════════════════════════════════════════════════
// ════ TAREFAS ALUNO ═════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const TarefasAluno = {
  listar:   (filtro)                  => get(`/aluno/tarefas?filtro=${filtro || ''}`),
  entregar: (id, conteudo, arquivo)   => post(`/aluno/tarefas/${id}/entregar`, { conteudo, arquivo_url: arquivo }),
};

// ════════════════════════════════════════════════════════════
// ════ MÓDULO DE APRENDIZADO ═════════════════════════════════
// ════════════════════════════════════════════════════════════
const Modulos = {
  listar:            ()          => get('/aluno/modulos'),
  buscarConteudo:    (id)        => get(`/aluno/modulos/${id}/conteudo`),
  atualizarProgresso:(id, pct)   => patch(`/aluno/modulos/${id}/progresso`, { pct }),
};

// ════════════════════════════════════════════════════════════
// ════ JOGOS & QUIZZES ═══════════════════════════════════════
// ════════════════════════════════════════════════════════════
const Quizzes = {
  listar:           ()              => get('/aluno/quizzes'),
  iniciar:          (quizId)        => post(`/aluno/quizzes/${quizId}/iniciar`),
  responder:        (tentId, dados) => post(`/aluno/tentativas/${tentId}/responder`, dados),
  finalizar:        (tentId)        => post(`/aluno/tentativas/${tentId}/finalizar`),
};

// ════════════════════════════════════════════════════════════
// ════ RECOMPENSAS ═══════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const Recompensas = {
  buscar: () => get('/aluno/recompensas'),
};

// ════════════════════════════════════════════════════════════
// ════ PROFESSOR ═════════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const Professor = {
  dashboard:         ()                      => get('/professor/dashboard'),
  criarTarefa:       (dados)                 => post('/professor/tarefas', dados),
  submissoesPendentes:(turmaId)              => get(`/professor/submissoes${turmaId ? `?turma_id=${turmaId}` : ''}`),
  corrigir:          (submId, nota, feedback)=> patch(`/professor/submissoes/${submId}/corrigir`, { nota, feedback }),
  listarAlunos:      (turmaId)               => get(`/professor/turmas/${turmaId}/alunos`),
  perfilAluno:       (alunoId)               => get(`/professor/alunos/${alunoId}/perfil`),
};

// ════════════════════════════════════════════════════════════
// ════ ADMIN ESCOLAR ═════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const AdminEscolar = {
  dashboard: () => get('/admin-escolar/dashboard'),
};

// ════════════════════════════════════════════════════════════
// ════ ADMIN GERAL ═══════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const AdminGeral = {
  dashboard:     ()           => get('/admin-geral/dashboard'),
  listarEscolas: (filtros)    => get(`/admin-geral/escolas?${new URLSearchParams(filtros || {})}`),
  criarEscola:   (dados)      => post('/admin-geral/escolas', dados),
};

// ════════════════════════════════════════════════════════════
// ════ FINANCEIRO ════════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const Financeiro = {
  buscar:      (ano)       => get(`/financeiro${ano ? `?ano=${ano}` : ''}`),
};

// ════════════════════════════════════════════════════════════
// ════ RELATÓRIOS ════════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const Relatorios = {
  engajamento: ()             => get('/relatorios/engajamento'),
  topAlunos:   (limite)       => get(`/relatorios/top-alunos?limite=${limite || 10}`),
};

// ════════════════════════════════════════════════════════════
// ════ CONFIGURAÇÕES ═════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const Configuracoes = {
  buscar:      ()       => get('/configuracoes'),
  salvar:      (dados)  => put('/configuracoes', dados),
};

// ════════════════════════════════════════════════════════════
// ════ NOTIFICAÇÕES ══════════════════════════════════════════
// ════════════════════════════════════════════════════════════
const Notificacoes = {
  listar:  ()   => get('/notificacoes'),
  marcarLida: (id) => patch(`/notificacoes/${id}/ler`),
};

// ─── EXPORTA TUDO ───────────────────────────────────────────
window.MonettoAPI = {
  Auth,
  DashboardAluno, PerfilAluno, TarefasAluno,
  Modulos, Quizzes, Recompensas,
  Professor, AdminEscolar, AdminGeral,
  Financeiro, Relatorios, Configuracoes, Notificacoes,
};
