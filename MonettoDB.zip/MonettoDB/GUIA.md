# 🔐 MONETTO — GUIA COMPLETO DE BANCO DE DADOS, INTEGRAÇÃO & SEGURANÇA

---

## 📁 ESTRUTURA DO PROJETO

```
MonettoDB/
├── schema.sql          ← Todas as tabelas PostgreSQL
├── src/
│   ├── db.js           ← Conexão ao banco (Pool + RLS)
│   ├── auth.js         ← Login, JWT, bcrypt, sessões
│   ├── queries.js      ← Todas as queries por tela
│   ├── routes.js       ← Rotas REST da API
│   └── server.js       ← Servidor Express + segurança
└── frontend/
    └── api.js          ← Cliente HTTP para o frontend
```

---

## 🗄️ TABELAS × TELAS — MAPA COMPLETO

| Tela                        | Tabelas usadas                                              |
|-----------------------------|-------------------------------------------------------------|
| login-principal             | `usuarios`, `sessoes`, `audit_logs`                         |
| login-aluno                 | `usuarios`, `sessoes`                                       |
| login-professor-admin       | `usuarios`, `sessoes`                                       |
| dashboard-aluno             | `usuarios`, `xp_historico`, `streaks`, `submissoes`, `tarefas` |
| perfil-aluno                | `usuarios`, `vw_xp_total`, `streaks`, `conquistas`, `usuario_conquistas`, `matriculas` |
| tarefas-aluno               | `tarefas`, `submissoes`, `turmas`, `matriculas`             |
| modulo-aprendizado          | `modulos`, `modulo_conteudos`, `progresso_modulos`          |
| jogos-quiz                  | `quizzes`, `quiz_questoes`, `quiz_opcoes`, `quiz_tentativas`, `quiz_respostas` |
| recompensas                 | `conquistas`, `usuario_conquistas`, `xp_historico`          |
| dashboard-professor         | `turmas`, `matriculas`, `tarefas`, `submissoes`             |
| criar-tarefas               | `tarefas`, `turmas`                                         |
| pagina-tarefas-prof         | `tarefas`, `submissoes`, `usuarios`                         |
| gerenciar-alunos            | `usuarios`, `matriculas`, `vw_xp_total`, `streaks`          |
| dashboard-admin-escolar     | `escolas`, `usuarios`, `turmas`, `progresso_modulos`        |
| gerenciar-professores       | `usuarios` (tipo=professor), `turmas`                       |
| relatorios                  | `vw_desempenho_aluno`, `xp_historico`, `relatorio_snapshots`|
| financeiro                  | `faturas`, `licencas`, `planos`, `escolas`                  |
| dashboard-admin-geral       | `escolas`, `usuarios`, `licencas`, `faturas`                |
| gerenciar-escola            | `escolas`, `licencas`, `planos`, `usuarios`                 |
| configuracoes (aluno)       | `configuracoes_usuario`                                     |
| configuracoes (prof/admin)  | `configuracoes_usuario`, `configuracoes_escola`             |

---

## ⚙️ COMO INSTALAR E RODAR

### 1. Requisitos
```
Node.js 18+
PostgreSQL 15+
```

### 2. Instalar dependências
```bash
cd MonettoDB
npm init -y
npm install express pg bcrypt jsonwebtoken cookie-parser \
            helmet cors compression dotenv
```

### 3. Criar o arquivo .env
```
# Banco
DB_HOST=localhost
DB_PORT=5432
DB_NAME=monetto
DB_USER=monetto_app
DB_PASSWORD=SUA_SENHA_SUPER_SEGURA

# Segurança — gere com: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
JWT_SECRET=GERE_64_CHARS_ALEATORIOS_AQUI
JWT_REFRESH_SECRET=OUTRO_SEGREDO_64_CHARS_AQUI
COOKIE_SECRET=MAIS_UM_SEGREDO_AQUI

# App
PORT=3001
NODE_ENV=development
CORS_ORIGINS=http://localhost:3000,http://localhost:5500
```

### 4. Criar o banco e rodar o schema
```bash
psql -U postgres -c "CREATE DATABASE monetto;"
psql -U postgres -c "CREATE USER monetto_app WITH PASSWORD 'SUA_SENHA';"
psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE monetto TO monetto_app;"
psql -U monetto_app -d monetto -f schema.sql
```

### 5. Rodar o servidor
```bash
node src/server.js
# API disponível em http://localhost:3001/api/v1
```

---

## 🔗 COMO LINKAR O FRONTEND AO BANCO

### Passo 1 — Adicione o `api.js` em cada página HTML

```html
<!-- No <head> de TODAS as páginas protegidas -->
<script src="../api.js"></script>
```

### Passo 2 — Proteja cada página com verificação de sessão

Cole este bloco no `<script>` de cada página:

```javascript
// Topo de cada página — verifica se o usuário está logado
(async () => {
  const usuario = await MonettoAPI.Auth.verificarSessao();
  if (!usuario) return; // redireciona automaticamente para login

  // Preenche dados do usuário na sidebar
  document.querySelector('.sb-user-info strong').textContent = usuario.nome;
})();
```

### Passo 3 — Conecte os dados reais às telas

#### Exemplo: dashboard-aluno.html
```javascript
// Substitua os dados estáticos do HTML por dados reais:
async function carregarDashboard() {
  const dados = await MonettoAPI.DashboardAluno.buscarResumo();

  // XP e nível
  document.querySelector('.xp-fill').style.width = calcPctXP(dados.resumo) + '%';
  document.querySelector('.nivel-num').textContent = dados.resumo.nivel;

  // Tarefas recentes
  const lista = document.querySelector('.tarefas-lista');
  lista.innerHTML = dados.tarefas.map(t => `
    <div class="tarefa-item">
      <span>${t.titulo}</span>
      <span class="status-${t.status}">${t.status}</span>
    </div>
  `).join('');
}
carregarDashboard();
```

#### Exemplo: login-principal.html
```javascript
document.querySelector('#form-login').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.querySelector('#email').value;
  const senha = document.querySelector('#senha').value;

  try {
    const usuario = await MonettoAPI.Auth.login(email, senha);

    // Redireciona conforme o tipo
    const rotas = {
      aluno:          '../dashboard-aluno/dashboard-aluno.html',
      professor:      '../dashboard-professor/dashboard-professor.html',
      admin_escolar:  '../dashboard-admin-escolar/dashboard-admin-escolar.html',
      admin_geral:    '../dashboard-admin-geral/dashboard-admin-geral.html',
    };
    window.location.href = rotas[usuario.tipo];

  } catch (err) {
    document.querySelector('.erro-login').textContent = err.message;
  }
});
```

#### Exemplo: sair da conta (em todas as páginas)
```javascript
// Substitua o confirm() atual por:
function sairDaConta() {
  MonettoAPI.Auth.logout(); // limpa token e redireciona
}
```

---

## 🛡️ SEGURANÇA — CAMADAS IMPLEMENTADAS

### Camada 1 — Senhas (bcrypt)
- **bcrypt com 12 rounds** — impossível de reverter mesmo com hash vazado
- Nunca salve senha em texto puro, nunca em `localStorage`
- Troca de senha sempre requer a senha atual

### Camada 2 — JWT (Access + Refresh)
```
Access Token  → 15 minutos de vida, salvo em MEMÓRIA (variável JS)
Refresh Token → 7 dias, salvo em COOKIE httpOnly (JavaScript NÃO consegue ler)
```
- Access Token curto evita uso por hackers mesmo se interceptado
- Refresh Token em `httpOnly` protege contra XSS (ataques de scripts maliciosos)
- Ao fazer logout, o refresh token é **revogado no banco** (tabela `sessoes`)

### Camada 3 — Headers HTTP (Helmet)
```
Strict-Transport-Security  → Força HTTPS por 1 ano
Content-Security-Policy    → Bloqueia scripts externos não autorizados
X-Frame-Options            → Impede clickjacking (a página não abre em iframe)
X-Content-Type-Options     → Impede MIME sniffing
Referrer-Policy            → Controla quais URLs são enviadas como referrer
```

### Camada 4 — CORS
- Só as origens listadas em `CORS_ORIGINS` podem chamar a API
- Em produção: `CORS_ORIGINS=https://app.monetto.com.br`
- Bloqueia chamadas de outros domínios (impede CSRF via fetch)

### Camada 5 — Rate Limiting
- Login: **máximo 10 tentativas por minuto por IP**
- API geral: **máximo 30 requisições por minuto**
- Evita ataques de força bruta e enumeração de usuários

### Camada 6 — Row Level Security (RLS) no PostgreSQL
```sql
-- O aluno SÓ vê seus próprios dados, mesmo que a query não filtre
SET LOCAL app.usuario_id = 'uuid-do-aluno';
SET LOCAL app.tipo_usuario = 'aluno';
-- RLS aplica o filtro automaticamente no banco
```
- Proteção no nível do banco — erro no código não expõe dados de outros
- Professor só acessa dados das suas turmas
- Admin Geral é o único com acesso completo

### Camada 7 — Auditoria
- Todo login/logout é registrado na tabela `audit_logs`
- IP e User-Agent registrados em cada sessão
- Tentativas de login falhadas também são salvas
- Admin Geral pode ver todos os logs

### Camada 8 — Validação de dados
- Parâmetros SQL sempre usando **$1, $2, $3...** (parameterized queries)
- Impossível de injeção SQL
- Limite de 2MB no body JSON
- Tipos de usuário validados no middleware `exigirTipo()`

---

## 🚀 CHECKLIST ANTES DE IR PARA PRODUÇÃO

```
□ .env com segredos reais (nunca commitar no git)
□ .gitignore incluindo .env e node_modules
□ NODE_ENV=production no servidor
□ CORS_ORIGINS apontando só para o domínio real
□ PostgreSQL com SSL habilitado
□ Backup automático do banco configurado
□ HTTPS obrigatório (certificado SSL/TLS)
□ Monitoramento de erros (ex: Sentry)
□ Logs de auditoria revisados periodicamente
□ Política de senha forte para usuários (mín. 8 chars)
□ 2FA para Admin Geral (recomendado)
```

---

## 🔌 ENDPOINTS DA API — REFERÊNCIA RÁPIDA

| Método | Rota                                   | Quem acessa       | Tela                  |
|--------|----------------------------------------|-------------------|-----------------------|
| POST   | /auth/login                            | Todos             | login-*               |
| POST   | /auth/logout                           | Todos             | Sidebar               |
| POST   | /auth/refresh                          | Automático        | api.js                |
| GET    | /aluno/dashboard                       | Aluno             | dashboard-aluno       |
| GET    | /aluno/perfil                          | Aluno             | perfil-aluno          |
| PUT    | /aluno/perfil                          | Aluno             | perfil-aluno          |
| GET    | /aluno/tarefas                         | Aluno             | tarefas-aluno         |
| POST   | /aluno/tarefas/:id/entregar            | Aluno             | tarefas-aluno         |
| GET    | /aluno/modulos                         | Aluno             | modulo-aprendizado    |
| PATCH  | /aluno/modulos/:id/progresso           | Aluno             | modulo-aprendizado    |
| GET    | /aluno/quizzes                         | Aluno             | jogos-quiz            |
| POST   | /aluno/quizzes/:id/iniciar             | Aluno             | jogos-quiz            |
| POST   | /aluno/tentativas/:id/finalizar        | Aluno             | jogos-quiz            |
| GET    | /aluno/recompensas                     | Aluno             | recompensas           |
| GET    | /professor/dashboard                   | Professor         | dashboard-professor   |
| POST   | /professor/tarefas                     | Professor         | criar-tarefas         |
| GET    | /professor/submissoes                  | Professor         | pagina-tarefas-prof   |
| PATCH  | /professor/submissoes/:id/corrigir     | Professor         | pagina-tarefas-prof   |
| GET    | /professor/turmas/:id/alunos           | Prof/AdminEscolar | gerenciar-alunos      |
| GET    | /admin-escolar/dashboard               | Admin Escolar     | dashboard-admin-escolar|
| GET    | /admin-geral/dashboard                 | Admin Geral       | dashboard-admin-geral |
| GET    | /admin-geral/escolas                   | Admin Geral       | gerenciar-escola      |
| POST   | /admin-geral/escolas                   | Admin Geral       | gerenciar-escola      |
| GET    | /financeiro                            | Admin Escolar/Geral| financeiro           |
| GET    | /relatorios/engajamento                | Prof/Admin        | relatorios            |
| GET    | /configuracoes                         | Todos             | configuracoes         |
| PUT    | /configuracoes                         | Todos             | configuracoes         |
| GET    | /notificacoes                          | Todos             | Sidebar (sino)        |
```
