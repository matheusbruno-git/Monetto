// ============================================================
//  MonettoDB — src/routes.js
//  Todas as rotas da API REST organizadas por tela
//  Express.js — prefixo base: /api/v1
// ============================================================

const express  = require('express');
const router   = express.Router();
const { verificarToken, exigirTipo, login, renovarToken, logout } = require('./auth');
const Q = require('./queries');

// ─── RATE LIMITER (básico) ──────────────────────────────────
const rateMap = new Map();
function rateLimiter(max = 30, windowMs = 60_000) {
  return (req, res, next) => {
    const key = req.ip;
    const now = Date.now();
    const entry = rateMap.get(key) || { count: 0, start: now };
    if (now - entry.start > windowMs) { entry.count = 0; entry.start = now; }
    entry.count++;
    rateMap.set(key, entry);
    if (entry.count > max) return res.status(429).json({ erro: 'Muitas requisições' });
    next();
  };
}

// ─── WRAPPER ASYNC ──────────────────────────────────────────
const wrap = fn => (req, res, next) => fn(req, res, next).catch(next);

// ════════════════════════════════════════════════════════════
// AUTH  (login-principal, login-aluno, login-professor-admin)
// ════════════════════════════════════════════════════════════
router.post('/auth/login', rateLimiter(10, 60_000), wrap(async (req, res) => {
  const { email, senha } = req.body;
  if (!email || !senha) return res.status(400).json({ erro: 'Email e senha obrigatórios' });
  const dados = await login(email, senha, req.ip, req.headers['user-agent']);
  // Refresh token em cookie httpOnly
  res.cookie('refresh_token', dados.refreshToken, {
    httpOnly: true, secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict', maxAge: 7 * 24 * 60 * 60 * 1000,
  });
  res.json({ accessToken: dados.accessToken, usuario: dados.usuario });
}));

router.post('/auth/refresh', wrap(async (req, res) => {
  const token = req.cookies?.refresh_token;
  if (!token) return res.status(401).json({ erro: 'Refresh token ausente' });
  const { accessToken } = await renovarToken(token);
  res.json({ accessToken });
}));

router.post('/auth/logout', verificarToken, wrap(async (req, res) => {
  const token = req.cookies?.refresh_token;
  await logout(token, req.usuario.sub);
  res.clearCookie('refresh_token');
  res.json({ ok: true });
}));

// ════════════════════════════════════════════════════════════
// DASHBOARD ALUNO
// ════════════════════════════════════════════════════════════
router.get('/aluno/dashboard', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const id = req.usuario.sub;
  const [resumo, tarefas, atividade] = await Promise.all([
    Q.DashboardAluno.buscarResumo(id),
    Q.DashboardAluno.buscarTarefasRecentes(id),
    Q.DashboardAluno.buscarAtividadeRecente(id),
  ]);
  res.json({ resumo, tarefas, atividade });
}));

// ════════════════════════════════════════════════════════════
// PERFIL ALUNO
// ════════════════════════════════════════════════════════════
router.get('/aluno/perfil', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const id = req.usuario.sub;
  const [perfil, conquistas] = await Promise.all([
    Q.PerfilAluno.buscarPerfil(id),
    Q.PerfilAluno.buscarConquistas(id),
  ]);
  res.json({ perfil, conquistas });
}));

router.put('/aluno/perfil', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const { nome, bio, avatar_emoji } = req.body;
  const atualizado = await Q.PerfilAluno.atualizarPerfil(req.usuario.sub, { nome, bio, avatar_emoji });
  res.json(atualizado);
}));

router.get('/aluno/ranking/:turmaId', verificarToken, wrap(async (req, res) => {
  const ranking = await Q.PerfilAluno.buscarRankingTurma(req.params.turmaId);
  res.json(ranking);
}));

// ════════════════════════════════════════════════════════════
// TAREFAS ALUNO
// ════════════════════════════════════════════════════════════
router.get('/aluno/tarefas', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const { filtro } = req.query;
  const tarefas = await Q.TarefasAluno.listar(req.usuario.sub, filtro);
  res.json(tarefas);
}));

router.post('/aluno/tarefas/:id/entregar', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const { conteudo, arquivo_url } = req.body;
  const sub = await Q.TarefasAluno.entregar(req.usuario.sub, req.params.id, conteudo, arquivo_url);
  res.status(201).json(sub);
}));

// ════════════════════════════════════════════════════════════
// MÓDULO DE APRENDIZADO
// ════════════════════════════════════════════════════════════
router.get('/aluno/modulos', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const modulos = await Q.ModuloAprendizado.listar(req.usuario.escola_id, req.usuario.sub);
  res.json(modulos);
}));

router.get('/aluno/modulos/:id/conteudo', verificarToken, wrap(async (req, res) => {
  const conteudo = await Q.ModuloAprendizado.buscarConteudo(req.params.id);
  res.json(conteudo);
}));

router.patch('/aluno/modulos/:id/progresso', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const { pct } = req.body;
  if (pct === undefined) return res.status(400).json({ erro: 'pct obrigatório' });
  const prog = await Q.ModuloAprendizado.atualizarProgresso(req.usuario.sub, req.params.id, pct);
  res.json(prog);
}));

// ════════════════════════════════════════════════════════════
// JOGOS & QUIZZES
// ════════════════════════════════════════════════════════════
router.get('/aluno/quizzes', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const quizzes = await Q.JogosQuiz.listarQuizzes(req.usuario.escola_id, req.usuario.sub);
  res.json(quizzes);
}));

router.post('/aluno/quizzes/:id/iniciar', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const tentativa = await Q.JogosQuiz.iniciarTentativa(req.params.id, req.usuario.sub);
  const questoes  = await Q.JogosQuiz.buscarQuestoes(req.params.id);
  res.status(201).json({ tentativa, questoes });
}));

router.post('/aluno/tentativas/:id/responder', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const { questao_id, opcao_id, texto_livre } = req.body;
  const correta = await Q.JogosQuiz.registrarResposta(req.params.id, questao_id, opcao_id, texto_livre);
  res.json({ correta });
}));

router.post('/aluno/tentativas/:id/finalizar', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const resultado = await Q.JogosQuiz.finalizarTentativa(req.params.id, req.usuario.sub);
  // Verificar conquistas desbloqueadas
  const novas = await Q.Recompensas.verificarEDesbloquear(req.usuario.sub);
  res.json({ resultado, conquistas_desbloqueadas: novas });
}));

// ════════════════════════════════════════════════════════════
// RECOMPENSAS
// ════════════════════════════════════════════════════════════
router.get('/aluno/recompensas', verificarToken, exigirTipo('aluno'), wrap(async (req, res) => {
  const conquistas = await Q.Recompensas.buscarConquistas(req.usuario.sub);
  res.json(conquistas);
}));

// ════════════════════════════════════════════════════════════
// DASHBOARD PROFESSOR
// ════════════════════════════════════════════════════════════
router.get('/professor/dashboard', verificarToken, exigirTipo('professor'), wrap(async (req, res) => {
  const id = req.usuario.sub;
  const [resumo, turmas] = await Promise.all([
    Q.DashboardProfessor.buscarResumo(id),
    Q.DashboardProfessor.buscarTurmas(id),
  ]);
  res.json({ resumo, turmas });
}));

// ════════════════════════════════════════════════════════════
// TAREFAS PROFESSOR (criar-tarefas, pagina-tarefas-prof)
// ════════════════════════════════════════════════════════════
router.post('/professor/tarefas', verificarToken, exigirTipo('professor'), wrap(async (req, res) => {
  const tarefa = await Q.GerenciarTarefas.criar(req.usuario.sub, req.body);
  res.status(201).json(tarefa);
}));

router.get('/professor/submissoes', verificarToken, exigirTipo('professor'), wrap(async (req, res) => {
  const { turma_id } = req.query;
  const subs = await Q.GerenciarTarefas.listarSubmisoesParaCorrigir(req.usuario.sub, turma_id);
  res.json(subs);
}));

router.patch('/professor/submissoes/:id/corrigir', verificarToken, exigirTipo('professor'), wrap(async (req, res) => {
  const { nota, feedback } = req.body;
  if (nota === undefined) return res.status(400).json({ erro: 'nota obrigatória' });
  const resultado = await Q.GerenciarTarefas.corrigir(req.params.id, nota, feedback);
  res.json(resultado);
}));

// ════════════════════════════════════════════════════════════
// GERENCIAR ALUNOS (professor)
// ════════════════════════════════════════════════════════════
router.get('/professor/turmas/:id/alunos', verificarToken, exigirTipo('professor', 'admin_escolar'), wrap(async (req, res) => {
  const alunos = await Q.GerenciarAlunos.listarPorTurma(req.params.id);
  res.json(alunos);
}));

router.get('/professor/alunos/:id/perfil', verificarToken, exigirTipo('professor', 'admin_escolar'), wrap(async (req, res) => {
  const dados = await Q.GerenciarAlunos.buscarPerfilCompleto(req.params.id);
  res.json(dados);
}));

// ════════════════════════════════════════════════════════════
// DASHBOARD ADMIN ESCOLAR
// ════════════════════════════════════════════════════════════
router.get('/admin-escolar/dashboard', verificarToken, exigirTipo('admin_escolar'), wrap(async (req, res) => {
  const [resumo, turmas] = await Promise.all([
    Q.DashboardAdminEscolar.buscarResumo(req.usuario.escola_id),
    Q.DashboardAdminEscolar.buscarDesempenhoTurmas(req.usuario.escola_id),
  ]);
  res.json({ resumo, turmas });
}));

// ════════════════════════════════════════════════════════════
// DASHBOARD ADMIN GERAL
// ════════════════════════════════════════════════════════════
router.get('/admin-geral/dashboard', verificarToken, exigirTipo('admin_geral'), wrap(async (req, res) => {
  const [resumo, escolas] = await Promise.all([
    Q.DashboardAdminGeral.buscarResumoGlobal(),
    Q.DashboardAdminGeral.listarEscolas(),
  ]);
  res.json({ resumo, escolas });
}));

// ════════════════════════════════════════════════════════════
// GERENCIAR ESCOLA (admin-geral)
// ════════════════════════════════════════════════════════════
router.get('/admin-geral/escolas', verificarToken, exigirTipo('admin_geral'), wrap(async (req, res) => {
  const { plano, status, busca } = req.query;
  const escolas = await Q.DashboardAdminGeral.listarEscolas({ plano, status, busca });
  res.json(escolas);
}));

router.post('/admin-geral/escolas', verificarToken, exigirTipo('admin_geral'), wrap(async (req, res) => {
  const { query } = require('./db');
  const { hashSenha } = require('./auth');
  const { nome, cnpj, cidade, estado, email_admin, plano, notas } = req.body;
  // Cria escola
  const { rows: [escola] } = await query(
    `INSERT INTO escolas (nome, cnpj, cidade, estado, email_admin, plano, notas)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [nome, cnpj, cidade, estado, email_admin, plano || 'free', notas]
  );
  // Cria usuário admin_escolar
  const senhaTemp = Math.random().toString(36).slice(-10);
  const hash = await hashSenha(senhaTemp);
  await query(
    `INSERT INTO usuarios (escola_id, nome, email, senha_hash, tipo)
     VALUES ($1, $2, $3, $4, 'admin_escolar')`,
    [escola.id, `Admin ${nome}`, email_admin, hash]
  );
  res.status(201).json({ escola, senha_temporaria: senhaTemp });
}));

// ════════════════════════════════════════════════════════════
// FINANCEIRO
// ════════════════════════════════════════════════════════════
router.get('/financeiro', verificarToken, exigirTipo('admin_escolar', 'admin_geral'), wrap(async (req, res) => {
  const escolaId = req.usuario.tipo === 'admin_geral'
    ? req.query.escola_id
    : req.usuario.escola_id;
  const [dados, faturas, uso] = await Promise.all([
    Q.Financeiro.buscarDadosEscola(escolaId),
    Q.Financeiro.listarFaturas(escolaId, req.query.ano ? parseInt(req.query.ano) : null),
    Q.Financeiro.buscarUsoAtual(escolaId),
  ]);
  res.json({ dados, faturas, uso });
}));

// ════════════════════════════════════════════════════════════
// RELATÓRIOS
// ════════════════════════════════════════════════════════════
router.get('/relatorios/engajamento', verificarToken, exigirTipo('professor', 'admin_escolar', 'admin_geral'), wrap(async (req, res) => {
  const escolaId = req.usuario.escola_id || req.query.escola_id;
  const dados = await Q.Relatorios.engajamentoSemanal(escolaId);
  res.json(dados);
}));

router.get('/relatorios/top-alunos', verificarToken, exigirTipo('professor', 'admin_escolar', 'admin_geral'), wrap(async (req, res) => {
  const escolaId = req.usuario.escola_id || req.query.escola_id;
  const dados = await Q.Relatorios.topAlunos(escolaId, parseInt(req.query.limite || '10'));
  res.json(dados);
}));

// ════════════════════════════════════════════════════════════
// CONFIGURAÇÕES
// ════════════════════════════════════════════════════════════
router.get('/configuracoes', verificarToken, wrap(async (req, res) => {
  const { query } = require('./db');
  const { rows } = await query(
    `SELECT * FROM configuracoes_usuario WHERE usuario_id = $1`, [req.usuario.sub]
  );
  res.json(rows[0] || {});
}));

router.put('/configuracoes', verificarToken, wrap(async (req, res) => {
  const { query } = require('./db');
  const { notif_email, notif_tarefas, notif_conquistas, tema, idioma, mostrar_ranking } = req.body;
  const { rows } = await query(
    `INSERT INTO configuracoes_usuario
       (usuario_id, notif_email, notif_tarefas, notif_conquistas, tema, idioma, mostrar_ranking)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT (usuario_id) DO UPDATE
       SET notif_email      = COALESCE($2, configuracoes_usuario.notif_email),
           notif_tarefas    = COALESCE($3, configuracoes_usuario.notif_tarefas),
           notif_conquistas = COALESCE($4, configuracoes_usuario.notif_conquistas),
           tema             = COALESCE($5, configuracoes_usuario.tema),
           idioma           = COALESCE($6, configuracoes_usuario.idioma),
           mostrar_ranking  = COALESCE($7, configuracoes_usuario.mostrar_ranking),
           atualizado_em    = NOW()
     RETURNING *`,
    [req.usuario.sub, notif_email, notif_tarefas, notif_conquistas, tema, idioma, mostrar_ranking]
  );
  res.json(rows[0]);
}));

// ════════════════════════════════════════════════════════════
// NOTIFICAÇÕES
// ════════════════════════════════════════════════════════════
router.get('/notificacoes', verificarToken, wrap(async (req, res) => {
  const { query } = require('./db');
  const { rows } = await query(
    `SELECT * FROM notificacoes WHERE usuario_id = $1
     ORDER BY criado_em DESC LIMIT 30`,
    [req.usuario.sub]
  );
  res.json(rows);
}));

router.patch('/notificacoes/:id/ler', verificarToken, wrap(async (req, res) => {
  const { query } = require('./db');
  await query(
    `UPDATE notificacoes SET lida = TRUE
     WHERE id = $1 AND usuario_id = $2`,
    [req.params.id, req.usuario.sub]
  );
  res.json({ ok: true });
}));

// ════════════════════════════════════════════════════════════
// ERRO HANDLER GLOBAL
// ════════════════════════════════════════════════════════════
router.use((err, req, res, _next) => {
  console.error('[API Error]', err.message);
  const status = err.status || 500;
  const msg    = status < 500 ? err.message : 'Erro interno do servidor';
  res.status(status).json({ erro: msg });
});

module.exports = router;
