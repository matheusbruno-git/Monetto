// ============================================================
//  MonettoDB — src/server.js
//  Servidor Express com toda a stack de segurança configurada
// ============================================================

require('dotenv').config();
const express      = require('express');
const helmet       = require('helmet');
const cors         = require('cors');
const cookieParser = require('cookie-parser');
const compression  = require('compression');
const { testarConexao } = require('./db');
const routes           = require('./routes');

const app  = express();
const PORT = process.env.PORT || 3001;

// ─── ORIGENS PERMITIDAS ─────────────────────────────────────
const ORIGENS_PERMITIDAS = (process.env.CORS_ORIGINS || 'http://localhost:3000')
  .split(',').map(o => o.trim());

// ════════════════════════════════════════════════════════════
// MIDDLEWARES DE SEGURANÇA
// ════════════════════════════════════════════════════════════

// 1. Helmet — headers HTTP seguros
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc:  ["'self'"],
      styleSrc:   ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc:    ["'self'", 'https://fonts.gstatic.com'],
      imgSrc:     ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"],
      frameSrc:   ["'none'"],
      objectSrc:  ["'none'"],
    },
  },
  hsts: {
    maxAge: 31_536_000,
    includeSubDomains: true,
    preload: true,
  },
  referrerPolicy: { policy: 'same-origin' },
}));

// 2. CORS — só origens autorizadas
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || ORIGENS_PERMITIDAS.includes(origin)) return cb(null, true);
    cb(new Error(`CORS bloqueado: ${origin}`));
  },
  credentials: true,          // necessário para cookies
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));

// 3. Cookie parser (para refresh token httpOnly)
app.use(cookieParser(process.env.COOKIE_SECRET));

// 4. Body parser com limite
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// 5. Compressão
app.use(compression());

// 6. Remover header X-Powered-By (já feito pelo helmet, mas explícito)
app.disable('x-powered-by');

// ─── LOG DE REQUISIÇÕES (simples) ───────────────────────────
if (process.env.NODE_ENV !== 'test') {
  app.use((req, _res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
  });
}

// ─── HEALTH CHECK ───────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', ts: new Date().toISOString() });
});

// ─── ROTAS DA API ────────────────────────────────────────────
app.use('/api/v1', routes);

// ─── 404 ─────────────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ erro: 'Rota não encontrada' });
});

// ─── INICIALIZAÇÃO ───────────────────────────────────────────
async function iniciar() {
  await testarConexao();
  app.listen(PORT, () => {
    console.log(`\n🚀 Monetto API rodando na porta ${PORT}`);
    console.log(`   Ambiente: ${process.env.NODE_ENV || 'development'}`);
    console.log(`   CORS: ${ORIGENS_PERMITIDAS.join(', ')}\n`);
  });
}

iniciar().catch(err => {
  console.error('Falha ao iniciar:', err);
  process.exit(1);
});

module.exports = app;
