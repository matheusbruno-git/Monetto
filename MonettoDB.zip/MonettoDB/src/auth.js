// ============================================================
//  MonettoDB — src/auth.js
//  Login, JWT (access + refresh), bcrypt, logout
//  Cobre: login-principal, login-aluno, login-professor-admin
// ============================================================

const bcrypt  = require('bcrypt');
const jwt     = require('jsonwebtoken');
const crypto  = require('crypto');
const { query, queryRLS } = require('./db');

const SALT_ROUNDS    = 12;
const ACCESS_TTL     = '15m';   // curto por segurança
const REFRESH_TTL    = '7d';
const JWT_SECRET     = process.env.JWT_SECRET;     // mín. 64 chars
const JWT_REFRESH    = process.env.JWT_REFRESH_SECRET;

if (!JWT_SECRET || !JWT_REFRESH) {
  throw new Error('[Auth] JWT_SECRET e JWT_REFRESH_SECRET são obrigatórios!');
}

// ─── HASH DE SENHA ──────────────────────────────────────────
async function hashSenha(senha) {
  return bcrypt.hash(senha, SALT_ROUNDS);
}

async function verificarSenha(senha, hash) {
  return bcrypt.compare(senha, hash);
}

// ─── GERAR TOKENS ───────────────────────────────────────────
function gerarAccessToken(usuario) {
  return jwt.sign(
    {
      sub:       usuario.id,
      email:     usuario.email,
      tipo:      usuario.tipo,
      escola_id: usuario.escola_id,
    },
    JWT_SECRET,
    { expiresIn: ACCESS_TTL, algorithm: 'HS256' }
  );
}

function gerarRefreshToken(usuario) {
  const token = jwt.sign(
    { sub: usuario.id, tipo: usuario.tipo },
    JWT_REFRESH,
    { expiresIn: REFRESH_TTL, algorithm: 'HS256' }
  );
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  return { token, tokenHash };
}

// ─── LOGIN ──────────────────────────────────────────────────
/**
 * Faz login do usuário.
 * Retorna accessToken, refreshToken e dados básicos do usuário.
 */
async function login(email, senha, ip = null, userAgent = null) {
  // 1. Busca usuário
  const { rows } = await query(
    `SELECT id, escola_id, nome, email, senha_hash, tipo, ativo, avatar_emoji
     FROM usuarios WHERE email = $1 LIMIT 1`,
    [email.toLowerCase().trim()]
  );

  const usuario = rows[0];

  // 2. Usuário não encontrado (mensagem genérica p/ evitar user enumeration)
  if (!usuario) throw new Error('Credenciais inválidas');

  // 3. Conta desativada
  if (!usuario.ativo) throw new Error('Conta desativada. Fale com o administrador.');

  // 4. Verifica senha
  const senhaOk = await verificarSenha(senha, usuario.senha_hash);
  if (!senhaOk) {
    // Registra tentativa falha
    await query(
      `INSERT INTO audit_logs (usuario_id, acao, ip_address, user_agent, sucesso)
       VALUES ($1, 'login_falhou', $2, $3, FALSE)`,
      [usuario.id, ip, userAgent]
    );
    throw new Error('Credenciais inválidas');
  }

  // 5. Gera tokens
  const accessToken              = gerarAccessToken(usuario);
  const { token: refreshToken, tokenHash } = gerarRefreshToken(usuario);

  // 6. Salva refresh token (hash) no banco
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  await query(
    `INSERT INTO sessoes (usuario_id, token_hash, ip_address, user_agent, expira_em)
     VALUES ($1, $2, $3, $4, $5)`,
    [usuario.id, tokenHash, ip, userAgent, expiresAt]
  );

  // 7. Atualiza último login
  await query(
    `UPDATE usuarios SET ultimo_login = NOW() WHERE id = $1`,
    [usuario.id]
  );

  // 8. Audit log
  await query(
    `INSERT INTO audit_logs (usuario_id, acao, ip_address, user_agent)
     VALUES ($1, 'login', $2, $3)`,
    [usuario.id, ip, userAgent]
  );

  return {
    accessToken,
    refreshToken,
    usuario: {
      id:        usuario.id,
      nome:      usuario.nome,
      email:     usuario.email,
      tipo:      usuario.tipo,
      escola_id: usuario.escola_id,
      avatar:    usuario.avatar_emoji,
    }
  };
}

// ─── REFRESH TOKEN ──────────────────────────────────────────
async function renovarToken(refreshToken) {
  let payload;
  try {
    payload = jwt.verify(refreshToken, JWT_REFRESH);
  } catch {
    throw new Error('Refresh token inválido ou expirado');
  }

  const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');

  const { rows } = await query(
    `SELECT s.id, s.usuario_id, s.expira_em, s.revogada,
            u.tipo, u.escola_id, u.email, u.nome, u.ativo
     FROM sessoes s
     JOIN usuarios u ON u.id = s.usuario_id
     WHERE s.token_hash = $1 LIMIT 1`,
    [tokenHash]
  );

  const sessao = rows[0];
  if (!sessao || sessao.revogada || new Date() > sessao.expira_em) {
    throw new Error('Sessão inválida ou expirada');
  }
  if (!sessao.ativo) throw new Error('Conta desativada');

  const novoAccess = gerarAccessToken(sessao);
  return { accessToken: novoAccess };
}

// ─── LOGOUT ─────────────────────────────────────────────────
async function logout(refreshToken, usuarioId) {
  if (!refreshToken) return;
  const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
  await query(
    `UPDATE sessoes SET revogada = TRUE WHERE token_hash = $1`,
    [tokenHash]
  );
  await query(
    `INSERT INTO audit_logs (usuario_id, acao) VALUES ($1, 'logout')`,
    [usuarioId]
  );
}

// ─── VERIFICAR ACCESS TOKEN (middleware) ────────────────────
function verificarToken(req, res, next) {
  const auth = req.headers['authorization'];
  if (!auth || !auth.startsWith('Bearer ')) {
    return res.status(401).json({ erro: 'Token ausente' });
  }
  const token = auth.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.usuario = payload;
    next();
  } catch (err) {
    const msg = err.name === 'TokenExpiredError' ? 'Token expirado' : 'Token inválido';
    return res.status(401).json({ erro: msg });
  }
}

// ─── MIDDLEWARE DE ROLE ──────────────────────────────────────
function exigirTipo(...tipos) {
  return (req, res, next) => {
    if (!tipos.includes(req.usuario?.tipo)) {
      return res.status(403).json({ erro: 'Acesso negado' });
    }
    next();
  };
}

module.exports = {
  hashSenha, verificarSenha,
  login, renovarToken, logout,
  verificarToken, exigirTipo,
};
