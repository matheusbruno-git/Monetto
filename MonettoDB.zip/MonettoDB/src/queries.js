// ============================================================
//  MonettoDB — src/queries.js
//  TODAS as queries organizadas por tela
//  Cada função = 1 operação usada em 1 tela específica
// ============================================================

const { query, queryRLS } = require('./db');

// ════════════════════════════════════════════════════════════
// 🏠 DASHBOARD ALUNO
// ════════════════════════════════════════════════════════════
const DashboardAluno = {

  async buscarResumo(alunoId) {
    const { rows } = await query(
      `SELECT
        u.nome, u.avatar_emoji,
        COALESCE(xp.xp_total, 0)       AS xp_total,
        COALESCE(xp.nivel_atual, 1)    AS nivel,
        COALESCE(str.streak_atual, 0)  AS streak,
        (SELECT COUNT(*) FROM submissoes s WHERE s.aluno_id = u.id
          AND s.status = 'corrigida')  AS tarefas_concluidas,
        (SELECT COUNT(*) FROM submissoes s
          JOIN tarefas t ON t.id = s.tarefa_id
          WHERE s.aluno_id = u.id AND s.status = 'pendente'
            AND t.data_entrega >= NOW())  AS tarefas_pendentes,
        (SELECT COUNT(*) FROM usuario_conquistas WHERE usuario_id = u.id) AS conquistas
       FROM usuarios u
       LEFT JOIN vw_xp_total xp  ON xp.usuario_id = u.id
       LEFT JOIN streaks str      ON str.usuario_id = u.id
       WHERE u.id = $1`,
      [alunoId]
    );
    return rows[0];
  },

  async buscarTarefasRecentes(alunoId, limite = 5) {
    const { rows } = await query(
      `SELECT t.id, t.titulo, t.tipo, t.xp_recompensa,
              t.data_entrega, s.status, s.nota,
              tu.nome AS turma_nome
       FROM tarefas t
       JOIN turmas tu ON tu.id = t.turma_id
       JOIN matriculas m ON m.turma_id = t.turma_id AND m.aluno_id = $1
       LEFT JOIN submissoes s ON s.tarefa_id = t.id AND s.aluno_id = $1
       WHERE t.visivel = TRUE
       ORDER BY t.data_entrega ASC NULLS LAST
       LIMIT $2`,
      [alunoId, limite]
    );
    return rows;
  },

  async buscarAtividadeRecente(alunoId, limite = 10) {
    const { rows } = await query(
      `SELECT origem, quantidade, descricao, criado_em
       FROM xp_historico
       WHERE usuario_id = $1
       ORDER BY criado_em DESC
       LIMIT $2`,
      [alunoId, limite]
    );
    return rows;
  },
};

// ════════════════════════════════════════════════════════════
// 👤 PERFIL ALUNO
// ════════════════════════════════════════════════════════════
const PerfilAluno = {

  async buscarPerfil(alunoId) {
    const { rows } = await query(
      `SELECT
        u.id, u.nome, u.email, u.bio, u.avatar_emoji,
        u.criado_em AS membro_desde,
        COALESCE(xp.xp_total, 0)      AS xp_total,
        COALESCE(xp.nivel_atual, 1)   AS nivel,
        COALESCE(str.streak_atual, 0) AS streak,
        str.streak_recorde,
        m.matricula_num,
        tu.nome AS turma_nome,
        pr.nome AS professor_nome
       FROM usuarios u
       LEFT JOIN vw_xp_total xp  ON xp.usuario_id = u.id
       LEFT JOIN streaks str      ON str.usuario_id = u.id
       LEFT JOIN matriculas m     ON m.aluno_id = u.id AND m.status = 'ativa'
       LEFT JOIN turmas tu        ON tu.id = m.turma_id
       LEFT JOIN usuarios pr      ON pr.id = tu.professor_id
       WHERE u.id = $1 LIMIT 1`,
      [alunoId]
    );
    return rows[0];
  },

  async buscarConquistas(alunoId) {
    const { rows } = await query(
      `SELECT c.codigo, c.nome, c.descricao, c.emoji, c.xp_bonus,
              uc.desbloqueado_em,
              CASE WHEN uc.id IS NOT NULL THEN TRUE ELSE FALSE END AS desbloqueado
       FROM conquistas c
       LEFT JOIN usuario_conquistas uc
         ON uc.conquista_id = c.id AND uc.usuario_id = $1
       ORDER BY uc.desbloqueado_em DESC NULLS LAST, c.nome`,
      [alunoId]
    );
    return rows;
  },

  async buscarRankingTurma(turmaId) {
    const { rows } = await query(
      `SELECT
        u.id, u.nome, u.avatar_emoji,
        COALESCE(xp.xp_total, 0) AS xp_total,
        RANK() OVER (ORDER BY COALESCE(xp.xp_total, 0) DESC) AS posicao
       FROM matriculas m
       JOIN usuarios u ON u.id = m.aluno_id
       LEFT JOIN vw_xp_total xp ON xp.usuario_id = u.id
       WHERE m.turma_id = $1 AND m.status = 'ativa'
       ORDER BY xp_total DESC
       LIMIT 10`,
      [turmaId]
    );
    return rows;
  },

  async atualizarPerfil(alunoId, { nome, bio, avatar_emoji }) {
    const { rows } = await query(
      `UPDATE usuarios
       SET nome = COALESCE($2, nome),
           bio  = COALESCE($3, bio),
           avatar_emoji = COALESCE($4, avatar_emoji)
       WHERE id = $1
       RETURNING id, nome, bio, avatar_emoji`,
      [alunoId, nome, bio, avatar_emoji]
    );
    return rows[0];
  },
};

// ════════════════════════════════════════════════════════════
// 📋 TAREFAS ALUNO
// ════════════════════════════════════════════════════════════
const TarefasAluno = {

  async listar(alunoId, filtro = 'todas') {
    let whereExtra = '';
    if (filtro === 'pendentes')  whereExtra = `AND (s.status = 'pendente' OR s.id IS NULL)`;
    if (filtro === 'entregues')  whereExtra = `AND s.status IN ('entregue','corrigida')`;
    if (filtro === 'atrasadas')  whereExtra = `AND t.data_entrega < NOW() AND (s.status IS NULL OR s.status = 'pendente')`;

    const { rows } = await query(
      `SELECT t.id, t.titulo, t.descricao, t.tipo, t.xp_recompensa,
              t.data_entrega, tu.nome AS turma,
              COALESCE(s.status, 'pendente') AS status,
              s.nota, s.feedback, s.entregue_em
       FROM tarefas t
       JOIN turmas tu ON tu.id = t.turma_id
       JOIN matriculas m ON m.turma_id = t.turma_id AND m.aluno_id = $1
       LEFT JOIN submissoes s ON s.tarefa_id = t.id AND s.aluno_id = $1
       WHERE t.visivel = TRUE ${whereExtra}
       ORDER BY t.data_entrega ASC NULLS LAST`,
      [alunoId]
    );
    return rows;
  },

  async entregar(alunoId, tarefaId, conteudo, arquivoUrl = null) {
    const { rows } = await query(
      `INSERT INTO submissoes (tarefa_id, aluno_id, conteudo, arquivo_url,
                               status, entregue_em)
       VALUES ($1, $2, $3, $4, 'entregue', NOW())
       ON CONFLICT (tarefa_id, aluno_id)
         DO UPDATE SET conteudo = $3, arquivo_url = $4,
                       status = 'entregue', entregue_em = NOW()
       RETURNING *`,
      [tarefaId, alunoId, conteudo, arquivoUrl]
    );
    return rows[0];
  },
};

// ════════════════════════════════════════════════════════════
// 📚 MÓDULO DE APRENDIZADO
// ════════════════════════════════════════════════════════════
const ModuloAprendizado = {

  async listar(escolaId, alunoId) {
    const { rows } = await query(
      `SELECT m.id, m.titulo, m.descricao, m.materia,
              m.nivel, m.xp_recompensa, m.ordem,
              COALESCE(p.status, 'nao_iniciado')  AS status,
              COALESCE(p.pct_concluido, 0)        AS pct_concluido,
              p.xp_ganho
       FROM modulos m
       LEFT JOIN progresso_modulos p
         ON p.modulo_id = m.id AND p.aluno_id = $2
       WHERE m.escola_id = $1 AND m.publicado = TRUE
       ORDER BY m.ordem, m.titulo`,
      [escolaId, alunoId]
    );
    return rows;
  },

  async buscarConteudo(moduloId) {
    const { rows } = await query(
      `SELECT * FROM modulo_conteudos
       WHERE modulo_id = $1 ORDER BY ordem`,
      [moduloId]
    );
    return rows;
  },

  async atualizarProgresso(alunoId, moduloId, pct) {
    const concluido = pct >= 100;
    const { rows } = await query(
      `INSERT INTO progresso_modulos
         (aluno_id, modulo_id, status, pct_concluido,
          xp_ganho, concluido_em)
       VALUES ($1, $2,
         CASE WHEN $3 >= 100 THEN 'concluido' WHEN $3 > 0 THEN 'em_progresso' ELSE 'nao_iniciado' END,
         $3,
         CASE WHEN $3 >= 100 THEN (SELECT xp_recompensa FROM modulos WHERE id = $2) ELSE 0 END,
         CASE WHEN $3 >= 100 THEN NOW() ELSE NULL END)
       ON CONFLICT (aluno_id, modulo_id)
         DO UPDATE SET pct_concluido = GREATEST(progresso_modulos.pct_concluido, $3),
                       status = CASE WHEN $3 >= 100 THEN 'concluido'
                                     WHEN $3 > 0    THEN 'em_progresso'
                                     ELSE progresso_modulos.status END,
                       xp_ganho = CASE WHEN $3 >= 100
                                   THEN (SELECT xp_recompensa FROM modulos WHERE id = $2)
                                   ELSE progresso_modulos.xp_ganho END,
                       concluido_em = CASE WHEN $3 >= 100 AND progresso_modulos.concluido_em IS NULL
                                      THEN NOW() ELSE progresso_modulos.concluido_em END,
                       atualizado_em = NOW()
       RETURNING *`,
      [alunoId, moduloId, pct]
    );
    // Se concluiu, adiciona XP ao histórico
    if (concluido) {
      const mod = await query(`SELECT xp_recompensa, titulo FROM modulos WHERE id = $1`, [moduloId]);
      if (mod.rows[0]?.xp_recompensa > 0) {
        await adicionarXP(alunoId, 'modulo', moduloId, mod.rows[0].xp_recompensa,
                          `Módulo concluído: ${mod.rows[0].titulo}`);
      }
    }
    return rows[0];
  },
};

// ════════════════════════════════════════════════════════════
// 🎮 JOGOS & QUIZZES
// ════════════════════════════════════════════════════════════
const JogosQuiz = {

  async listarQuizzes(escolaId, alunoId) {
    const { rows } = await query(
      `SELECT q.id, q.titulo, q.descricao, q.materia,
              q.xp_recompensa, q.tempo_limite,
              COUNT(qq.id) AS total_questoes,
              COALESCE(MAX(qt.pct_acerto), 0) AS melhor_pct,
              COUNT(qt.id) AS vezes_jogado
       FROM quizzes q
       LEFT JOIN quiz_questoes qq ON qq.quiz_id = q.id
       LEFT JOIN quiz_tentativas qt ON qt.quiz_id = q.id AND qt.aluno_id = $2
       WHERE q.escola_id = $1 AND q.publicado = TRUE
       GROUP BY q.id
       ORDER BY q.titulo`,
      [escolaId, alunoId]
    );
    return rows;
  },

  async iniciarTentativa(quizId, alunoId) {
    const { rows } = await query(
      `INSERT INTO quiz_tentativas (quiz_id, aluno_id)
       VALUES ($1, $2) RETURNING *`,
      [quizId, alunoId]
    );
    return rows[0];
  },

  async buscarQuestoes(quizId) {
    const { rows } = await query(
      `SELECT qq.id, qq.enunciado, qq.tipo, qq.ordem,
              JSON_AGG(
                JSON_BUILD_OBJECT('id', qo.id, 'texto', qo.texto, 'ordem', qo.ordem)
                ORDER BY qo.ordem
              ) AS opcoes
       FROM quiz_questoes qq
       LEFT JOIN quiz_opcoes qo ON qo.questao_id = qq.id
       WHERE qq.quiz_id = $1
       GROUP BY qq.id
       ORDER BY qq.ordem`,
      [quizId]
    );
    return rows;
  },

  async registrarResposta(tentativaId, questaoId, opcaoId, textoLivre = null) {
    // Verifica se a resposta é correta
    let correta = null;
    if (opcaoId) {
      const { rows } = await query(
        `SELECT correta FROM quiz_opcoes WHERE id = $1`, [opcaoId]
      );
      correta = rows[0]?.correta;
    }
    await query(
      `INSERT INTO quiz_respostas
         (tentativa_id, questao_id, opcao_id, texto_livre, correta)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT DO NOTHING`,
      [tentativaId, questaoId, opcaoId, textoLivre, correta]
    );
    return correta;
  },

  async finalizarTentativa(tentativaId, alunoId) {
    // Calcula resultado
    const { rows: res } = await query(
      `SELECT
         COUNT(*) FILTER (WHERE correta = TRUE) AS acertos,
         COUNT(*) AS total,
         ROUND(COUNT(*) FILTER (WHERE correta = TRUE) * 100.0 / NULLIF(COUNT(*), 0)) AS pct
       FROM quiz_respostas WHERE tentativa_id = $1`,
      [tentativaId]
    );
    const { acertos, pct } = res[0];
    const { rows: tt } = await query(
      `UPDATE quiz_tentativas
       SET pontuacao = $2, pct_acerto = $3, concluido = TRUE,
           concluido_em = NOW(),
           tempo_gasto = EXTRACT(EPOCH FROM (NOW() - iniciado_em))::INT
       WHERE id = $1
       RETURNING quiz_id, xp_ganho`,
      [tentativaId, acertos, pct]
    );
    const tentativa = tt[0];
    // XP proporcional ao acerto
    const { rows: q } = await query(
      `SELECT xp_recompensa, titulo FROM quizzes WHERE id = $1`, [tentativa.quiz_id]
    );
    const xpGanho = Math.round((pct / 100) * q[0].xp_recompensa);
    if (xpGanho > 0) {
      await adicionarXP(alunoId, 'quiz', tentativa.quiz_id, xpGanho,
                        `Quiz: ${q[0].titulo} — ${pct}% de acerto`);
    }
    return { acertos, pct, xpGanho };
  },
};

// ════════════════════════════════════════════════════════════
// 🏆 RECOMPENSAS
// ════════════════════════════════════════════════════════════
const Recompensas = {

  async buscarConquistas(alunoId) {
    return PerfilAluno.buscarConquistas(alunoId);
  },

  async verificarEDesbloquear(alunoId) {
    // Verifica todas as conquistas e desbloqueia as que o aluno merece
    const { rows: conquistas } = await query(
      `SELECT c.* FROM conquistas c
       WHERE c.id NOT IN (
         SELECT conquista_id FROM usuario_conquistas WHERE usuario_id = $1
       )`,
      [alunoId]
    );

    const desbloqueadas = [];
    for (const c of conquistas) {
      const cond = c.condicao;
      if (!cond) continue;

      let atingiu = false;
      if (cond.tipo === 'tarefas_concluidas') {
        const { rows } = await query(
          `SELECT COUNT(*) AS n FROM submissoes
           WHERE aluno_id = $1 AND status = 'corrigida'`, [alunoId]
        );
        atingiu = parseInt(rows[0].n) >= cond.valor;
      } else if (cond.tipo === 'streak_dias') {
        const { rows } = await query(
          `SELECT streak_atual FROM streaks WHERE usuario_id = $1`, [alunoId]
        );
        atingiu = (rows[0]?.streak_atual || 0) >= cond.valor;
      } else if (cond.tipo === 'nivel') {
        const { rows } = await query(
          `SELECT nivel_atual FROM vw_xp_total WHERE usuario_id = $1`, [alunoId]
        );
        atingiu = (rows[0]?.nivel_atual || 1) >= cond.valor;
      }

      if (atingiu) {
        await query(
          `INSERT INTO usuario_conquistas (usuario_id, conquista_id)
           VALUES ($1, $2) ON CONFLICT DO NOTHING`,
          [alunoId, c.id]
        );
        if (c.xp_bonus > 0) {
          await adicionarXP(alunoId, 'conquista', c.id, c.xp_bonus,
                            `Conquista: ${c.nome}`);
        }
        desbloqueadas.push(c);
      }
    }
    return desbloqueadas;
  },
};

// ════════════════════════════════════════════════════════════
// 👨‍🏫 DASHBOARD PROFESSOR
// ════════════════════════════════════════════════════════════
const DashboardProfessor = {

  async buscarResumo(professorId) {
    const { rows } = await query(
      `SELECT
        COUNT(DISTINCT m.aluno_id)    AS total_alunos,
        COUNT(DISTINCT t.id)          AS total_turmas,
        COUNT(DISTINCT ta.id)         AS total_tarefas,
        COUNT(DISTINCT s.id) FILTER (WHERE s.status = 'entregue') AS para_corrigir
       FROM turmas t
       LEFT JOIN matriculas m  ON m.turma_id = t.id AND m.status = 'ativa'
       LEFT JOIN tarefas ta    ON ta.turma_id = t.id
       LEFT JOIN submissoes s  ON s.tarefa_id = ta.id
       WHERE t.professor_id = $1 AND t.ativa = TRUE`,
      [professorId]
    );
    return rows[0];
  },

  async buscarTurmas(professorId) {
    const { rows } = await query(
      `SELECT t.id, t.nome, t.ano_letivo,
              COUNT(m.id) AS total_alunos,
              ROUND(AVG(
                CASE WHEN s.status = 'corrigida' THEN s.nota END
              ), 2) AS media_notas
       FROM turmas t
       LEFT JOIN matriculas m ON m.turma_id = t.id AND m.status = 'ativa'
       LEFT JOIN tarefas ta   ON ta.turma_id = t.id
       LEFT JOIN submissoes s ON s.tarefa_id = ta.id
       WHERE t.professor_id = $1 AND t.ativa = TRUE
       GROUP BY t.id
       ORDER BY t.nome`,
      [professorId]
    );
    return rows;
  },
};

// ════════════════════════════════════════════════════════════
// 📝 CRIAR / GERENCIAR TAREFAS (professor)
// ════════════════════════════════════════════════════════════
const GerenciarTarefas = {

  async criar(professorId, dados) {
    const { turma_id, titulo, descricao, tipo, xp_recompensa, data_entrega } = dados;
    const { rows } = await query(
      `INSERT INTO tarefas
         (turma_id, criado_por, titulo, descricao, tipo, xp_recompensa, data_entrega)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [turma_id, professorId, titulo, descricao, tipo, xp_recompensa, data_entrega]
    );
    return rows[0];
  },

  async listarSubmisoesParaCorrigir(professorId, turmaId = null) {
    const { rows } = await query(
      `SELECT s.id, s.conteudo, s.arquivo_url, s.entregue_em, s.status,
              t.titulo AS tarefa_titulo,
              u.nome   AS aluno_nome, u.email AS aluno_email
       FROM submissoes s
       JOIN tarefas t  ON t.id = s.tarefa_id
       JOIN turmas tu  ON tu.id = t.turma_id
       JOIN usuarios u ON u.id = s.aluno_id
       WHERE tu.professor_id = $1
         AND s.status = 'entregue'
         AND ($2::UUID IS NULL OR tu.id = $2)
       ORDER BY s.entregue_em ASC`,
      [professorId, turmaId]
    );
    return rows;
  },

  async corrigir(submissaoId, nota, feedback) {
    const { rows } = await query(
      `UPDATE submissoes
       SET nota = $2, feedback = $3, status = 'corrigida', corrigida_em = NOW()
       WHERE id = $1 RETURNING aluno_id, tarefa_id`,
      [submissaoId, nota, feedback]
    );
    const sub = rows[0];
    // Adiciona XP ao aluno baseado na nota (nota 10 = XP completo)
    const { rows: t } = await query(
      `SELECT xp_recompensa, titulo FROM tarefas WHERE id = $1`, [sub.tarefa_id]
    );
    const xp = Math.round((nota / 10) * t[0].xp_recompensa);
    if (xp > 0) {
      await adicionarXP(sub.aluno_id, 'tarefa', sub.tarefa_id, xp,
                        `Tarefa corrigida: ${t[0].titulo} (nota ${nota})`);
    }
    return rows[0];
  },
};

// ════════════════════════════════════════════════════════════
// 👥 GERENCIAR ALUNOS
// ════════════════════════════════════════════════════════════
const GerenciarAlunos = {

  async listarPorTurma(turmaId) {
    const { rows } = await query(
      `SELECT
        u.id, u.nome, u.email, u.avatar_emoji,
        m.matricula_num, m.status AS matricula_status,
        COALESCE(xp.xp_total, 0)      AS xp_total,
        COALESCE(xp.nivel_atual, 1)   AS nivel,
        COALESCE(str.streak_atual, 0) AS streak,
        COUNT(s.id) FILTER (WHERE s.status = 'corrigida') AS tarefas_concluidas,
        COUNT(s.id)                   AS tarefas_total
       FROM matriculas m
       JOIN usuarios u ON u.id = m.aluno_id
       LEFT JOIN vw_xp_total xp ON xp.usuario_id = u.id
       LEFT JOIN streaks str    ON str.usuario_id = u.id
       LEFT JOIN submissoes s   ON s.aluno_id = u.id
       WHERE m.turma_id = $1
       GROUP BY u.id, m.matricula_num, m.status, xp.xp_total, xp.nivel_atual, str.streak_atual
       ORDER BY xp_total DESC`,
      [turmaId]
    );
    return rows;
  },

  async buscarPerfilCompleto(alunoId) {
    const perfil  = await PerfilAluno.buscarPerfil(alunoId);
    const conquistas = await PerfilAluno.buscarConquistas(alunoId);
    const atividade  = await DashboardAluno.buscarAtividadeRecente(alunoId, 5);
    return { perfil, conquistas, atividade };
  },
};

// ════════════════════════════════════════════════════════════
// 🏫 DASHBOARD ADMIN ESCOLAR
// ════════════════════════════════════════════════════════════
const DashboardAdminEscolar = {

  async buscarResumo(escolaId) {
    const { rows } = await query(
      `SELECT
        (SELECT COUNT(*) FROM usuarios WHERE escola_id = $1 AND tipo = 'aluno' AND ativo = TRUE) AS total_alunos,
        (SELECT COUNT(*) FROM usuarios WHERE escola_id = $1 AND tipo = 'professor' AND ativo = TRUE) AS total_professores,
        (SELECT COUNT(*) FROM turmas WHERE escola_id = $1 AND ativa = TRUE) AS total_turmas,
        (SELECT ROUND(AVG(pct_concluido)) FROM progresso_modulos pm
          JOIN usuarios u ON u.id = pm.aluno_id
          WHERE u.escola_id = $1) AS media_engajamento`,
      [escolaId]
    );
    return rows[0];
  },

  async buscarDesempenhoTurmas(escolaId) {
    const { rows } = await query(
      `SELECT t.id, t.nome,
              COUNT(DISTINCT m.aluno_id) AS alunos,
              ROUND(AVG(COALESCE(xp.xp_total, 0))) AS media_xp,
              pr.nome AS professor
       FROM turmas t
       JOIN usuarios pr ON pr.id = t.professor_id
       LEFT JOIN matriculas m ON m.turma_id = t.id AND m.status = 'ativa'
       LEFT JOIN vw_xp_total xp ON xp.usuario_id = m.aluno_id
       WHERE t.escola_id = $1 AND t.ativa = TRUE
       GROUP BY t.id, pr.nome
       ORDER BY media_xp DESC`,
      [escolaId]
    );
    return rows;
  },
};

// ════════════════════════════════════════════════════════════
// 🌐 DASHBOARD ADMIN GERAL
// ════════════════════════════════════════════════════════════
const DashboardAdminGeral = {

  async buscarResumoGlobal() {
    const { rows } = await query(
      `SELECT
        (SELECT COUNT(*) FROM escolas WHERE status = 'ativa')  AS escolas_ativas,
        (SELECT COUNT(*) FROM usuarios WHERE tipo = 'aluno')   AS total_alunos,
        (SELECT COUNT(*) FROM usuarios WHERE tipo = 'professor') AS total_professores,
        (SELECT COALESCE(SUM(valor), 0) FROM faturas WHERE status = 'pago'
           AND pago_em >= DATE_TRUNC('month', NOW())) AS mrr_atual`
    );
    return rows[0];
  },

  async listarEscolas(filtros = {}) {
    const { plano, status, busca } = filtros;
    const { rows } = await query(
      `SELECT e.id, e.nome, e.cidade, e.estado, e.status,
              e.plano, e.criado_em,
              COUNT(DISTINCT u.id) FILTER (WHERE u.tipo = 'aluno')     AS total_alunos,
              COUNT(DISTINCT u.id) FILTER (WHERE u.tipo = 'professor') AS total_professores,
              COUNT(DISTINCT t.id)                                       AS total_turmas,
              l.fim AS licenca_fim
       FROM escolas e
       LEFT JOIN usuarios u ON u.escola_id = e.id AND u.ativo = TRUE
       LEFT JOIN turmas t   ON t.escola_id = e.id AND t.ativa = TRUE
       LEFT JOIN LATERAL (
         SELECT fim FROM licencas
         WHERE escola_id = e.id AND status = 'ativa'
         ORDER BY fim DESC LIMIT 1
       ) l ON TRUE
       WHERE ($1::VARCHAR IS NULL OR e.plano = $1)
         AND ($2::VARCHAR IS NULL OR e.status = $2)
         AND ($3::TEXT    IS NULL OR e.nome ILIKE '%' || $3 || '%')
       GROUP BY e.id, l.fim
       ORDER BY e.criado_em DESC`,
      [plano || null, status || null, busca || null]
    );
    return rows;
  },
};

// ════════════════════════════════════════════════════════════
// 💳 FINANCEIRO
// ════════════════════════════════════════════════════════════
const Financeiro = {

  async buscarDadosEscola(escolaId) {
    const { rows } = await query(
      `SELECT e.nome, e.plano,
              l.inicio, l.fim, l.status AS licenca_status, l.renovacao_auto,
              p.nome AS plano_nome, p.preco_mensal,
              p.max_alunos, p.max_professores, p.max_turmas
       FROM escolas e
       JOIN licencas l ON l.escola_id = e.id AND l.status = 'ativa'
       JOIN planos p   ON p.id = l.plano_id
       WHERE e.id = $1
       ORDER BY l.fim DESC LIMIT 1`,
      [escolaId]
    );
    return rows[0];
  },

  async listarFaturas(escolaId, ano = null) {
    const { rows } = await query(
      `SELECT f.id, f.numero, f.valor, f.status,
              f.metodo_pagamento, f.vencimento, f.pago_em,
              f.periodo_inicio, f.periodo_fim
       FROM faturas f
       WHERE f.escola_id = $1
         AND ($2::INT IS NULL OR EXTRACT(YEAR FROM f.criado_em) = $2)
       ORDER BY f.criado_em DESC`,
      [escolaId, ano]
    );
    return rows;
  },

  async buscarUsoAtual(escolaId) {
    const { rows } = await query(
      `SELECT
        COUNT(*) FILTER (WHERE tipo = 'aluno')     AS alunos_ativos,
        COUNT(*) FILTER (WHERE tipo = 'professor') AS professores_ativos
       FROM usuarios WHERE escola_id = $1 AND ativo = TRUE`,
      [escolaId]
    );
    const { rows: turmas } = await query(
      `SELECT COUNT(*) AS turmas_ativas FROM turmas WHERE escola_id = $1 AND ativa = TRUE`,
      [escolaId]
    );
    return { ...rows[0], ...turmas[0] };
  },
};

// ════════════════════════════════════════════════════════════
// 📊 RELATÓRIOS
// ════════════════════════════════════════════════════════════
const Relatorios = {

  async engajamentoSemanal(escolaId) {
    const { rows } = await query(
      `SELECT
        DATE_TRUNC('week', xp.criado_em) AS semana,
        COUNT(DISTINCT xp.usuario_id)    AS alunos_ativos,
        SUM(xp.quantidade)               AS xp_total_semana
       FROM xp_historico xp
       JOIN usuarios u ON u.id = xp.usuario_id
       WHERE u.escola_id = $1
         AND xp.criado_em >= NOW() - INTERVAL '12 weeks'
       GROUP BY semana ORDER BY semana`,
      [escolaId]
    );
    return rows;
  },

  async topAlunos(escolaId, limite = 10) {
    const { rows } = await query(
      `SELECT u.nome, u.avatar_emoji,
              COALESCE(xp.xp_total, 0) AS xp_total,
              xp.nivel_atual,
              t.nome AS turma
       FROM usuarios u
       LEFT JOIN vw_xp_total xp ON xp.usuario_id = u.id
       LEFT JOIN matriculas m   ON m.aluno_id = u.id AND m.status = 'ativa'
       LEFT JOIN turmas t        ON t.id = m.turma_id
       WHERE u.escola_id = $1 AND u.tipo = 'aluno'
       ORDER BY xp_total DESC
       LIMIT $2`,
      [escolaId, limite]
    );
    return rows;
  },
};

// ════════════════════════════════════════════════════════════
// ⚡ XP — HELPER INTERNO
// ════════════════════════════════════════════════════════════
async function adicionarXP(usuarioId, origem, referenciaId, quantidade, descricao) {
  await query(
    `INSERT INTO xp_historico
       (usuario_id, origem, referencia_id, quantidade, descricao)
     VALUES ($1, $2, $3, $4, $5)`,
    [usuarioId, origem, referenciaId, quantidade, descricao]
  );
  // Atualiza streak
  await atualizarStreak(usuarioId);
}

async function atualizarStreak(usuarioId) {
  const hoje = new Date().toISOString().split('T')[0];
  // Registra dia ativo
  await query(
    `INSERT INTO streak_dias (usuario_id, data) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
    [usuarioId, hoje]
  );
  // Recalcula streak
  const { rows } = await query(
    `WITH dias_ordenados AS (
       SELECT data, data - (ROW_NUMBER() OVER (ORDER BY data))::INT AS grp
       FROM streak_dias WHERE usuario_id = $1
     ),
     grupos AS (
       SELECT grp, COUNT(*) AS tamanho, MAX(data) AS ultimo_dia
       FROM dias_ordenados GROUP BY grp
     )
     SELECT tamanho, ultimo_dia FROM grupos
     WHERE ultimo_dia >= CURRENT_DATE - 1
     ORDER BY ultimo_dia DESC LIMIT 1`,
    [usuarioId]
  );
  const streakAtual = rows[0]?.tamanho || 0;
  await query(
    `INSERT INTO streaks (usuario_id, streak_atual, streak_recorde, ultimo_dia_ativo)
     VALUES ($1, $2, $2, $3)
     ON CONFLICT (usuario_id) DO UPDATE
       SET streak_atual = $2,
           streak_recorde = GREATEST(streaks.streak_recorde, $2),
           ultimo_dia_ativo = $3,
           atualizado_em = NOW()`,
    [usuarioId, streakAtual, hoje]
  );
}

module.exports = {
  DashboardAluno, PerfilAluno, TarefasAluno,
  ModuloAprendizado, JogosQuiz, Recompensas,
  DashboardProfessor, GerenciarTarefas, GerenciarAlunos,
  DashboardAdminEscolar, DashboardAdminGeral,
  Financeiro, Relatorios,
  adicionarXP, atualizarStreak,
};
