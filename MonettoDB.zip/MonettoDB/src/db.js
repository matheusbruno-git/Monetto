// ============================================================
//  MonettoDB — src/db.js
//  Conexão central com o banco (PostgreSQL em prod, SQLite em dev)
//  Node.js + pg (postgres) ou better-sqlite3 (Electron local)
// ============================================================

const { Pool } = require('pg');

// ─── CONFIGURAÇÃO ──────────────────────────────────────────
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // ou individualmente:
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME     || 'monetto',
  user:     process.env.DB_USER     || 'monetto_app',
  password: process.env.DB_PASSWORD,
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: true }
    : false,
  max:          10,    // máx de conexões no pool
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
});

// ─── HELPER: executa query com contexto RLS ─────────────────
/**
 * Executa uma query dentro de uma transação com o contexto
 * do usuário logado, ativando Row Level Security.
 *
 * @param {string} usuarioId   - UUID do usuário
 * @param {string} tipoUsuario - 'aluno' | 'professor' | 'admin_escolar' | 'admin_geral'
 * @param {string} sql         - Query SQL
 * @param {Array}  params      - Parâmetros
 */
async function queryRLS(usuarioId, tipoUsuario, sql, params = []) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Define variáveis de sessão para as políticas RLS
    await client.query(`SET LOCAL app.usuario_id    = '${usuarioId}'`);
    await client.query(`SET LOCAL app.tipo_usuario  = '${tipoUsuario}'`);
    const result = await client.query(sql, params);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

// ─── HELPER: query simples (sem RLS) ────────────────────────
async function query(sql, params = []) {
  return pool.query(sql, params);
}

// ─── TESTAR CONEXÃO ─────────────────────────────────────────
pool.on('error', (err) => {
  console.error('[DB] Erro inesperado no pool:', err.message);
});

async function testarConexao() {
  try {
    const res = await pool.query('SELECT NOW() AS agora');
    console.log('[DB] ✅ Conectado ao PostgreSQL:', res.rows[0].agora);
  } catch (err) {
    console.error('[DB] ❌ Falha na conexão:', err.message);
    process.exit(1);
  }
}

module.exports = { pool, query, queryRLS, testarConexao };
