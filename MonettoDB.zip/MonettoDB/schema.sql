-- =============================================================
--  MONETTO DATABASE SCHEMA — COMPLETO
--  Banco: PostgreSQL 15+
--  Criado para: Electron App (Node.js + better-sqlite3 local)
--               ou PostgreSQL remoto em produção
--  Encoding: UTF-8
-- =============================================================

-- ─────────────────────────────────────────────
-- EXTENSÕES
-- ─────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =============================================================
-- 1. ESCOLAS  (tela: gerenciar-escola, dashboard-admin-geral)
-- =============================================================
CREATE TABLE escolas (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome          VARCHAR(200) NOT NULL,
    cnpj          VARCHAR(20)  UNIQUE,
    cidade        VARCHAR(100) NOT NULL,
    estado        CHAR(2)      NOT NULL,
    email_admin   VARCHAR(200) NOT NULL,
    telefone      VARCHAR(20),
    endereco      TEXT,
    logo_url      TEXT,
    plano         VARCHAR(20)  NOT NULL DEFAULT 'free'
                  CHECK (plano IN ('free','basic','premium','enterprise')),
    status        VARCHAR(20)  NOT NULL DEFAULT 'ativa'
                  CHECK (status IN ('ativa','pausada','suspensa','cancelada')),
    notas         TEXT,
    criado_em     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    atualizado_em TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- =============================================================
-- 2. USUÁRIOS  (base para todos os logins)
-- =============================================================
CREATE TABLE usuarios (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    escola_id       UUID REFERENCES escolas(id) ON DELETE CASCADE,
    nome            VARCHAR(200) NOT NULL,
    email           VARCHAR(200) NOT NULL UNIQUE,
    senha_hash      TEXT         NOT NULL,  -- bcrypt
    tipo            VARCHAR(20)  NOT NULL
                    CHECK (tipo IN ('aluno','professor','admin_escolar','admin_geral')),
    avatar_emoji    VARCHAR(10)  DEFAULT '🧑‍🎓',
    bio             TEXT,
    ativo           BOOLEAN      NOT NULL DEFAULT TRUE,
    email_verificado BOOLEAN     NOT NULL DEFAULT FALSE,
    ultimo_login    TIMESTAMPTZ,
    criado_em       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    atualizado_em   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_usuarios_escola ON usuarios(escola_id);
CREATE INDEX idx_usuarios_tipo   ON usuarios(tipo);
CREATE INDEX idx_usuarios_email  ON usuarios(email);

-- =============================================================
-- 3. SESSÕES / TOKENS  (login, logout, refresh)
-- =============================================================
CREATE TABLE sessoes (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id    UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    token_hash    TEXT NOT NULL UNIQUE,   -- SHA-256 do JWT refresh token
    ip_address    INET,
    user_agent    TEXT,
    expira_em     TIMESTAMPTZ NOT NULL,
    revogada      BOOLEAN NOT NULL DEFAULT FALSE,
    criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_sessoes_usuario ON sessoes(usuario_id);
CREATE INDEX idx_sessoes_token   ON sessoes(token_hash);

-- =============================================================
-- 4. TURMAS  (dashboard-professor, gerenciar-alunos)
-- =============================================================
CREATE TABLE turmas (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    escola_id     UUID NOT NULL REFERENCES escolas(id) ON DELETE CASCADE,
    professor_id  UUID NOT NULL REFERENCES usuarios(id),
    nome          VARCHAR(100) NOT NULL,   -- ex: "8º Ano A"
    descricao     TEXT,
    ano_letivo    SMALLINT NOT NULL DEFAULT EXTRACT(YEAR FROM NOW())::SMALLINT,
    ativa         BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_turmas_escola    ON turmas(escola_id);
CREATE INDEX idx_turmas_professor ON turmas(professor_id);

-- =============================================================
-- 5. MATRÍCULAS  (aluno ↔ turma)
-- =============================================================
CREATE TABLE matriculas (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    turma_id   UUID NOT NULL REFERENCES turmas(id) ON DELETE CASCADE,
    aluno_id   UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    matricula_num VARCHAR(30) UNIQUE,
    data_inicio DATE NOT NULL DEFAULT CURRENT_DATE,
    data_fim    DATE,
    status      VARCHAR(20) NOT NULL DEFAULT 'ativa'
                CHECK (status IN ('ativa','trancada','concluida')),
    criado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(turma_id, aluno_id)
);
CREATE INDEX idx_matriculas_turma ON matriculas(turma_id);
CREATE INDEX idx_matriculas_aluno ON matriculas(aluno_id);

-- =============================================================
-- 6. MÓDULOS DE APRENDIZADO  (modulo-aprendizado)
-- =============================================================
CREATE TABLE modulos (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    escola_id     UUID REFERENCES escolas(id) ON DELETE CASCADE,
    titulo        VARCHAR(200) NOT NULL,
    descricao     TEXT,
    materia       VARCHAR(100),           -- ex: "Matemática", "Ed. Financeira"
    nivel         VARCHAR(20) DEFAULT 'basico'
                  CHECK (nivel IN ('basico','intermediario','avancado')),
    xp_recompensa SMALLINT NOT NULL DEFAULT 50,
    ordem         SMALLINT NOT NULL DEFAULT 0,
    publicado     BOOLEAN NOT NULL DEFAULT FALSE,
    criado_por    UUID REFERENCES usuarios(id),
    criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Conteúdo dentro dos módulos (vídeos, textos, PDFs)
CREATE TABLE modulo_conteudos (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    modulo_id  UUID NOT NULL REFERENCES modulos(id) ON DELETE CASCADE,
    tipo       VARCHAR(20) NOT NULL CHECK (tipo IN ('texto','video','pdf','link')),
    titulo     VARCHAR(200) NOT NULL,
    corpo      TEXT,           -- HTML ou texto
    url        TEXT,           -- para vídeo / PDF / link
    ordem      SMALLINT NOT NULL DEFAULT 0,
    criado_em  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_mod_conteudos_modulo ON modulo_conteudos(modulo_id);

-- Progresso do aluno por módulo
CREATE TABLE progresso_modulos (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    aluno_id       UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    modulo_id      UUID NOT NULL REFERENCES modulos(id) ON DELETE CASCADE,
    status         VARCHAR(20) NOT NULL DEFAULT 'nao_iniciado'
                   CHECK (status IN ('nao_iniciado','em_progresso','concluido')),
    pct_concluido  SMALLINT NOT NULL DEFAULT 0 CHECK (pct_concluido BETWEEN 0 AND 100),
    xp_ganho       SMALLINT NOT NULL DEFAULT 0,
    concluido_em   TIMESTAMPTZ,
    atualizado_em  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(aluno_id, modulo_id)
);
CREATE INDEX idx_prog_modulos_aluno  ON progresso_modulos(aluno_id);
CREATE INDEX idx_prog_modulos_modulo ON progresso_modulos(modulo_id);

-- =============================================================
-- 7. TAREFAS  (criar-tarefas, pagina-tarefas-prof, tarefas-aluno)
-- =============================================================
CREATE TABLE tarefas (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    turma_id      UUID NOT NULL REFERENCES turmas(id) ON DELETE CASCADE,
    criado_por    UUID NOT NULL REFERENCES usuarios(id),
    titulo        VARCHAR(300) NOT NULL,
    descricao     TEXT,
    tipo          VARCHAR(30) NOT NULL DEFAULT 'texto'
                  CHECK (tipo IN ('texto','multipla_escolha','arquivo','quiz','projeto')),
    xp_recompensa SMALLINT NOT NULL DEFAULT 30,
    data_entrega  TIMESTAMPTZ,
    visivel       BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_tarefas_turma     ON tarefas(turma_id);
CREATE INDEX idx_tarefas_criado_por ON tarefas(criado_por);

-- Submissões (aluno entrega a tarefa)
CREATE TABLE submissoes (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tarefa_id    UUID NOT NULL REFERENCES tarefas(id) ON DELETE CASCADE,
    aluno_id     UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    conteudo     TEXT,          -- resposta escrita
    arquivo_url  TEXT,          -- se tipo = arquivo
    nota         NUMERIC(5,2),  -- 0.00 a 10.00
    feedback     TEXT,          -- comentário do professor
    status       VARCHAR(20) NOT NULL DEFAULT 'pendente'
                 CHECK (status IN ('pendente','entregue','corrigida','atrasada')),
    entregue_em  TIMESTAMPTZ,
    corrigida_em TIMESTAMPTZ,
    criado_em    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tarefa_id, aluno_id)
);
CREATE INDEX idx_submissoes_tarefa ON submissoes(tarefa_id);
CREATE INDEX idx_submissoes_aluno  ON submissoes(aluno_id);

-- =============================================================
-- 8. JOGOS & QUIZZES  (jogos-quiz)
-- =============================================================
CREATE TABLE quizzes (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    escola_id     UUID REFERENCES escolas(id) ON DELETE CASCADE,
    criado_por    UUID REFERENCES usuarios(id),
    titulo        VARCHAR(200) NOT NULL,
    descricao     TEXT,
    materia       VARCHAR(100),
    xp_recompensa SMALLINT NOT NULL DEFAULT 40,
    tempo_limite  SMALLINT,    -- segundos, NULL = sem limite
    publicado     BOOLEAN NOT NULL DEFAULT FALSE,
    criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE quiz_questoes (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quiz_id     UUID NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    enunciado   TEXT NOT NULL,
    tipo        VARCHAR(20) NOT NULL DEFAULT 'multipla'
                CHECK (tipo IN ('multipla','verdadeiro_falso','dissertativa')),
    ordem       SMALLINT NOT NULL DEFAULT 0,
    pontos      SMALLINT NOT NULL DEFAULT 1
);
CREATE INDEX idx_questoes_quiz ON quiz_questoes(quiz_id);

CREATE TABLE quiz_opcoes (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    questao_id   UUID NOT NULL REFERENCES quiz_questoes(id) ON DELETE CASCADE,
    texto        TEXT NOT NULL,
    correta      BOOLEAN NOT NULL DEFAULT FALSE,
    ordem        SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX idx_opcoes_questao ON quiz_opcoes(questao_id);

-- Tentativas de quiz pelo aluno
CREATE TABLE quiz_tentativas (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quiz_id       UUID NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    aluno_id      UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    pontuacao     SMALLINT NOT NULL DEFAULT 0,
    pct_acerto    SMALLINT NOT NULL DEFAULT 0,
    xp_ganho      SMALLINT NOT NULL DEFAULT 0,
    tempo_gasto   SMALLINT,   -- segundos
    concluido     BOOLEAN NOT NULL DEFAULT FALSE,
    iniciado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    concluido_em  TIMESTAMPTZ
);
CREATE INDEX idx_tentativas_quiz  ON quiz_tentativas(quiz_id);
CREATE INDEX idx_tentativas_aluno ON quiz_tentativas(aluno_id);

-- Respostas por questão dentro de uma tentativa
CREATE TABLE quiz_respostas (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tentativa_id UUID NOT NULL REFERENCES quiz_tentativas(id) ON DELETE CASCADE,
    questao_id   UUID NOT NULL REFERENCES quiz_questoes(id),
    opcao_id     UUID REFERENCES quiz_opcoes(id),
    texto_livre  TEXT,        -- para dissertativas
    correta      BOOLEAN,
    criado_em    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_respostas_tentativa ON quiz_respostas(tentativa_id);

-- =============================================================
-- 9. XP & NÍVEIS  (dashboard-aluno, perfil-aluno)
-- =============================================================
CREATE TABLE xp_config (
    nivel         SMALLINT PRIMARY KEY,
    xp_necessario INT NOT NULL,
    titulo        VARCHAR(100),   -- ex: "Iniciante", "Expert"
    cor_hex       CHAR(7)
);
-- Dados iniciais de níveis
INSERT INTO xp_config VALUES
(1,    0,    'Iniciante',    '#9B59B6'),
(2,  100,    'Aprendiz',     '#5B9BF8'),
(3,  250,    'Estudante',    '#2ECC71'),
(4,  500,    'Dedicado',     '#FFD700'),
(5,  800,    'Expert',       '#F39C12'),
(6, 1200,    'Mestre',       '#E74C3C'),
(7, 1800,    'Lendário',     '#ff6b35'),
(8, 2600,    'Gênio',        '#c39bd3'),
(9, 3600,    'Supremo',      '#fff'),
(10,5000,    'Monetto Pro',  '#FFD700');

CREATE TABLE xp_historico (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id  UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    origem      VARCHAR(50) NOT NULL
                CHECK (origem IN ('tarefa','quiz','modulo','streak','conquista','bonus')),
    referencia_id UUID,          -- id da tarefa/quiz/modulo que gerou
    quantidade  SMALLINT NOT NULL,
    descricao   TEXT,
    criado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_xp_usuario   ON xp_historico(usuario_id);
CREATE INDEX idx_xp_criado_em ON xp_historico(criado_em);

-- Saldo atual de XP (view materializada para performance)
CREATE VIEW vw_xp_total AS
SELECT
    usuario_id,
    SUM(quantidade)  AS xp_total,
    (SELECT nivel FROM xp_config
     WHERE xp_necessario <= SUM(quantidade)
     ORDER BY nivel DESC LIMIT 1) AS nivel_atual
FROM xp_historico
GROUP BY usuario_id;

-- =============================================================
-- 10. CONQUISTAS / BADGES  (recompensas, perfil-aluno)
-- =============================================================
CREATE TABLE conquistas (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codigo      VARCHAR(50) UNIQUE NOT NULL,  -- ex: 'primeiro_passo'
    nome        VARCHAR(100) NOT NULL,
    descricao   TEXT,
    emoji       VARCHAR(10),
    xp_bonus    SMALLINT NOT NULL DEFAULT 0,
    condicao    JSONB,   -- ex: {"tipo":"tarefas_concluidas","valor":1}
    criado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Dados iniciais de conquistas
INSERT INTO conquistas (codigo, nome, descricao, emoji, xp_bonus, condicao) VALUES
('primeiro_passo',   'Primeiro Passo',   'Conclua sua primeira tarefa',         '🎯', 20,  '{"tipo":"tarefas_concluidas","valor":1}'),
('em_chamas',        'Em Chamas',        '5 dias consecutivos de atividade',    '🔥', 50,  '{"tipo":"streak_dias","valor":5}'),
('genio',            'Gênio',            '100% de acerto em um quiz',           '💡', 30,  '{"tipo":"quiz_acerto","valor":100}'),
('rei_da_turma',     'Rei da Turma',     'Seja o 1º no ranking da turma',       '👑', 100, '{"tipo":"ranking_posicao","valor":1}'),
('nivel_5',          'Nível 5',          'Alcance o Nível 5',                   '⚡', 80,  '{"tipo":"nivel","valor":5}'),
('gamer_pro',        'Gamer Pro',        'Complete 10 quizzes',                 '🎮', 40,  '{"tipo":"quizzes_completos","valor":10}'),
('estudioso',        'Estudioso',        'Entregue 50 tarefas',                 '📚', 100, '{"tipo":"tarefas_concluidas","valor":50}'),
('30_dias',          '30 Dias',          'Sequência de 30 dias',                '🏆', 200, '{"tipo":"streak_dias","valor":30}');

CREATE TABLE usuario_conquistas (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id    UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    conquista_id  UUID NOT NULL REFERENCES conquistas(id),
    desbloqueado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(usuario_id, conquista_id)
);
CREATE INDEX idx_uc_usuario ON usuario_conquistas(usuario_id);

-- =============================================================
-- 11. STREAK  (perfil-aluno, dashboard-aluno)
-- =============================================================
CREATE TABLE streaks (
    usuario_id        UUID PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
    streak_atual      SMALLINT NOT NULL DEFAULT 0,
    streak_recorde    SMALLINT NOT NULL DEFAULT 0,
    ultimo_dia_ativo  DATE,
    atualizado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE streak_dias (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id  UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    data        DATE NOT NULL,
    UNIQUE(usuario_id, data)
);
CREATE INDEX idx_streak_dias_usuario ON streak_dias(usuario_id);

-- =============================================================
-- 12. PLANOS & LICENÇAS  (financeiro)
-- =============================================================
CREATE TABLE planos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codigo          VARCHAR(30) UNIQUE NOT NULL,  -- 'free','basic','premium','enterprise'
    nome            VARCHAR(100) NOT NULL,
    preco_mensal    NUMERIC(10,2) NOT NULL DEFAULT 0,
    max_alunos      INT,          -- NULL = ilimitado
    max_professores INT,
    max_turmas      INT,
    features        JSONB,        -- lista de funcionalidades
    ativo           BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO planos (codigo, nome, preco_mensal, max_alunos, max_professores, max_turmas) VALUES
('free',       'Free',       0.00,    30,   1,   2),
('basic',      'Basic',      1200.00, 150,  10,  10),
('premium',    'Premium',    4800.00, NULL, NULL, NULL),
('enterprise', 'Enterprise', 0.00,    NULL, NULL, NULL);

CREATE TABLE licencas (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    escola_id   UUID NOT NULL REFERENCES escolas(id) ON DELETE CASCADE,
    plano_id    UUID NOT NULL REFERENCES planos(id),
    inicio      DATE NOT NULL DEFAULT CURRENT_DATE,
    fim         DATE,
    status      VARCHAR(20) NOT NULL DEFAULT 'ativa'
                CHECK (status IN ('ativa','vencida','cancelada','trial')),
    renovacao_auto BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_licencas_escola ON licencas(escola_id);

CREATE TABLE faturas (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    escola_id       UUID NOT NULL REFERENCES escolas(id),
    licenca_id      UUID REFERENCES licencas(id),
    numero          VARCHAR(30) UNIQUE NOT NULL,  -- ex: 'INV-2026-04'
    valor           NUMERIC(10,2) NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'pendente'
                    CHECK (status IN ('pendente','pago','vencido','cancelado')),
    metodo_pagamento VARCHAR(50),   -- 'cartao', 'boleto', 'pix'
    referencia_pgto  TEXT,          -- ID externo do gateway
    periodo_inicio  DATE,
    periodo_fim     DATE,
    vencimento      DATE,
    pago_em         TIMESTAMPTZ,
    criado_em       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_faturas_escola ON faturas(escola_id);

-- =============================================================
-- 13. RELATÓRIOS / ANALYTICS  (relatorios, dashboard-admin-*)
-- =============================================================
CREATE TABLE relatorio_snapshots (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    escola_id   UUID REFERENCES escolas(id),
    turma_id    UUID REFERENCES turmas(id),
    tipo        VARCHAR(50) NOT NULL,  -- 'engajamento_semanal','tarefas_turma',...
    dados       JSONB NOT NULL,
    periodo_ini DATE,
    periodo_fim DATE,
    gerado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_rel_escola ON relatorio_snapshots(escola_id);
CREATE INDEX idx_rel_turma  ON relatorio_snapshots(turma_id);

-- View: desempenho por aluno (usada em relatorios e dashboard-professor)
CREATE VIEW vw_desempenho_aluno AS
SELECT
    u.id            AS aluno_id,
    u.nome          AS aluno_nome,
    t.id            AS turma_id,
    t.nome          AS turma_nome,
    COUNT(DISTINCT s.id) FILTER (WHERE s.status = 'corrigida') AS tarefas_concluidas,
    COUNT(DISTINCT s.id)                                         AS tarefas_total,
    ROUND(AVG(s.nota), 2)                                        AS media_nota,
    COALESCE(xp.xp_total, 0)                                     AS xp_total,
    COALESCE(str.streak_atual, 0)                                AS streak_atual
FROM usuarios u
JOIN matriculas m  ON m.aluno_id  = u.id
JOIN turmas t      ON t.id        = m.turma_id
LEFT JOIN submissoes s ON s.aluno_id = u.id
LEFT JOIN vw_xp_total xp ON xp.usuario_id = u.id
LEFT JOIN streaks str    ON str.usuario_id = u.id
WHERE u.tipo = 'aluno'
GROUP BY u.id, u.nome, t.id, t.nome, xp.xp_total, str.streak_atual;

-- =============================================================
-- 14. LOGS DE AUDITORIA  (segurança, admin-geral)
-- =============================================================
CREATE TABLE audit_logs (
    id          BIGSERIAL PRIMARY KEY,
    usuario_id  UUID REFERENCES usuarios(id) ON DELETE SET NULL,
    acao        VARCHAR(100) NOT NULL,   -- 'login','logout','criar_tarefa',...
    tabela      VARCHAR(100),
    registro_id UUID,
    dados_antes JSONB,
    dados_depois JSONB,
    ip_address  INET,
    user_agent  TEXT,
    sucesso     BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_audit_usuario   ON audit_logs(usuario_id);
CREATE INDEX idx_audit_criado_em ON audit_logs(criado_em);
CREATE INDEX idx_audit_acao      ON audit_logs(acao);

-- =============================================================
-- 15. CONFIGURAÇÕES DO SISTEMA  (configuracoes, configuracoes-prof)
-- =============================================================
CREATE TABLE configuracoes_usuario (
    usuario_id           UUID PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
    notif_email          BOOLEAN NOT NULL DEFAULT TRUE,
    notif_tarefas        BOOLEAN NOT NULL DEFAULT TRUE,
    notif_conquistas     BOOLEAN NOT NULL DEFAULT TRUE,
    notif_ranking        BOOLEAN NOT NULL DEFAULT FALSE,
    tema                 VARCHAR(20) NOT NULL DEFAULT 'escuro' CHECK (tema IN ('escuro','claro')),
    idioma               VARCHAR(10) NOT NULL DEFAULT 'pt-BR',
    mostrar_xp_publico   BOOLEAN NOT NULL DEFAULT TRUE,
    mostrar_ranking      BOOLEAN NOT NULL DEFAULT TRUE,
    atualizado_em        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE configuracoes_escola (
    escola_id              UUID PRIMARY KEY REFERENCES escolas(id) ON DELETE CASCADE,
    permitir_auto_cadastro BOOLEAN NOT NULL DEFAULT FALSE,
    xp_multiplicador       NUMERIC(3,2) NOT NULL DEFAULT 1.00,
    dias_entrega_extra     SMALLINT NOT NULL DEFAULT 2,
    notif_responsaveis     BOOLEAN NOT NULL DEFAULT TRUE,
    atualizado_em          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================
-- 16. NOTIFICAÇÕES  (todas as telas — sino no header)
-- =============================================================
CREATE TABLE notificacoes (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id  UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    tipo        VARCHAR(50) NOT NULL,  -- 'nova_tarefa','conquista','feedback',...
    titulo      VARCHAR(200) NOT NULL,
    mensagem    TEXT,
    link        TEXT,          -- ex: '/tarefas-aluno'
    lida        BOOLEAN NOT NULL DEFAULT FALSE,
    criado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_notif_usuario ON notificacoes(usuario_id);
CREATE INDEX idx_notif_lida    ON notificacoes(usuario_id, lida);

-- =============================================================
-- 17. TRIGGERS — atualiza "atualizado_em" automaticamente
-- =============================================================
CREATE OR REPLACE FUNCTION fn_atualizar_timestamp()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.atualizado_em = NOW(); RETURN NEW; END; $$;

DO $$ DECLARE t TEXT;
BEGIN FOR t IN
  SELECT unnest(ARRAY[
    'escolas','usuarios','turmas','modulos',
    'tarefas','configuracoes_usuario','configuracoes_escola','streaks'
  ])
LOOP
  EXECUTE format('CREATE TRIGGER trg_upd_%I BEFORE UPDATE ON %I
                  FOR EACH ROW EXECUTE FUNCTION fn_atualizar_timestamp()', t, t);
END LOOP; END $$;

-- =============================================================
-- 18. ROW LEVEL SECURITY (RLS)
-- =============================================================
ALTER TABLE usuarios               ENABLE ROW LEVEL SECURITY;
ALTER TABLE turmas                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE matriculas             ENABLE ROW LEVEL SECURITY;
ALTER TABLE tarefas                ENABLE ROW LEVEL SECURITY;
ALTER TABLE submissoes             ENABLE ROW LEVEL SECURITY;
ALTER TABLE xp_historico           ENABLE ROW LEVEL SECURITY;
ALTER TABLE notificacoes           ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs             ENABLE ROW LEVEL SECURITY;

-- Política: aluno só vê seus próprios dados
CREATE POLICY pol_usuarios_proprio
  ON usuarios FOR SELECT
  USING (id = current_setting('app.usuario_id')::UUID
      OR tipo = 'admin_geral');

CREATE POLICY pol_notif_proprio
  ON notificacoes FOR ALL
  USING (usuario_id = current_setting('app.usuario_id')::UUID);

CREATE POLICY pol_xp_proprio
  ON xp_historico FOR SELECT
  USING (usuario_id = current_setting('app.usuario_id')::UUID);

-- Política: professor só vê suas turmas
CREATE POLICY pol_turmas_professor
  ON turmas FOR ALL
  USING (professor_id = current_setting('app.usuario_id')::UUID
      OR current_setting('app.tipo_usuario') IN ('admin_escolar','admin_geral'));

-- Política: audit_logs só admin_geral
CREATE POLICY pol_audit_admin
  ON audit_logs FOR SELECT
  USING (current_setting('app.tipo_usuario') = 'admin_geral');
