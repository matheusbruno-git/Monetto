(() => {
  const container = document.getElementById("sidebar-container");
  if (!container) return;

  const sidebar = "../../Assets/Components/admin-school-sidebar.html";

  const toggleSidebar = () => {
    const isHidden = container.hidden;
    container.hidden = !isHidden;
    container.setAttribute("aria-hidden", String(isHidden));
    document.body.classList.toggle("sidebar-open", isHidden);
  };

  const menuTriggers = Array.from(
    document.querySelectorAll(
      "#menu, #menu-toggle, #sidebar-toggle, #menu-button, .menu-toggle, .sidebar-toggle, .menu-btn, [data-sidebar-toggle]"
    )
  );

  const initializeSidebarState = () => {
    container.hidden = true;
    container.setAttribute("aria-hidden", "true");
    document.body.classList.remove("sidebar-open");
  };

  initializeSidebarState();

  menuTriggers.forEach((trigger) => {
    trigger.addEventListener("click", (event) => {
      event.preventDefault();
      toggleSidebar();
    });
  });

  console.log(`Loading sidebar from: ${sidebar}`);

  fetch(sidebar, { cache: "no-store" })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`Failed to load sidebar: ${response.status}`);
      }
      return response.text();
    })
    .then((html) => {
      container.innerHTML = html;
      initializeSidebarState();
    })
    .catch((err) => {
      console.error(err);
    });
})();

function getCurrentUserId() {
  try {
    const session = JSON.parse(localStorage.getItem('session') || '{}');
    return session.id_usuario || session.id || null;
  } catch (e) {
    return null;
  }
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function renderTeachers(teachers) {
  const el = document.getElementById('teachers-list');
  if (!el) return;
  if (!teachers || !teachers.length) {
    el.innerHTML = '<div class="teach-item"><div class="teach-info"><strong>Nenhum professor cadastrado</strong></div></div>';
    return;
  }
  el.innerHTML = teachers.map(t => `
    <div class="teach-item">
      <div class="tav ${t.avatarClass || 'ta1'}">${t.emoji || ''}</div>
      <div class="teach-info"><strong>${t.name}</strong><span>${t.subtitle || ''}</span></div>
    </div>`).join('');
}

function renderAlerts(alerts) {
  const el = document.getElementById('alerts-list');
  if (!el) return;
  if (!alerts || !alerts.length) {
    el.innerHTML = '<div class="alert-item al-blue"><div class="alert-body"><strong>Nenhum alerta</strong></div></div>';
    return;
  }
  el.innerHTML = alerts.map(a => `
    <div class="alert-item al-${a.level}">
      <div class="alert-icon">${a.icon}</div>
      <div class="alert-body"><strong>${a.title}</strong><span>${a.subtitle}</span></div>
    </div>`).join('');
}

function renderClasses(classes) {
  const el = document.getElementById('turmas-list');
  if (!el) return;
  if (!classes || !classes.length) {
    el.innerHTML = '<div class="turma-row"><div>Nenhuma turma cadastrada</div><div>—</div><div>—</div><div>—</div></div>';
    return;
  }
  el.innerHTML = classes.map(c => `
    <div class="turma-row">
      <div style="font-size:.85rem;font-weight:600">${c.name}</div>
      <div style="color:var(--muted);font-size:.82rem">${c.students}</div>
      <div>${c.completion}%</div>
      <div><span class="${c.statusClass}">${c.statusLabel}</span></div>
    </div>`).join('');
}

function renderXpChart(xpChart) {
  const el = document.getElementById('xp-chart');
  if (!el) return;
  if (!xpChart || !xpChart.length) return;
  const max = Math.max(...xpChart.map(b => b.height), 1);
  el.innerHTML = xpChart.map(b => `
    <div class="bc">
      <div class="bc-bar blue" style="height:${Math.max(4, (b.height / max) * 90)}px"></div>
      <div class="bc-lbl">${b.label}</div>
    </div>`).join('');
}

function renderActivities(activities) {
  const el = document.getElementById('activities-list');
  if (!el) return;
  if (!activities || !activities.length) {
    el.innerHTML = '<div class="act-item"><div class="act-body"><strong>Nenhuma atividade recente</strong></div></div>';
    return;
  }
  el.innerHTML = activities.map(a => `
    <div class="act-item">
      <div class="act-icon ${a.iconClass}">${a.icon}</div>
      <div class="act-body"><strong>${a.title}</strong><span>${a.subtitle}</span></div>
      <div class="act-time">${a.time}</div>
    </div>`).join('');
}

async function loadDashboard() {
  const userId = getCurrentUserId();

  if (!userId) {
    console.error("Usuário não encontrado na sessão.");
    return;
  }

  try {
    const result = await window.api.getDashboardAdminEscolar(userId);

    console.log(" DASHBOARD RESULT:", result);

    if (!result || !result.success) {
      console.error(
        "Erro ao carregar dashboard:",
        result?.message
      );
      return;
    }

    const data = result.data;

    // Escola
    setText("school-name", data.school?.name || "Escola");
    setText(
      "school-subtitle",
      data.school?.subtitle || "Dashboard do Administrador Escolar"
    );

    // Header
    setText(
      "alunos-count",
      data.school?.stats?.[0]?.value ?? 0
    );

    setText(
      "professores-count",
      data.school?.stats?.[1]?.value ?? 0
    );

    setText(
      "turmas-count",
      data.school?.stats?.[2]?.value ?? 0
    );

    // Stats
    setText(
      "alunos-matriculados-count",
      data.stats?.[0]?.value ?? 0
    );

    setText(
      "completion-rate",
      data.stats?.[1]?.value ?? "0%"
    );

    setText(
      "tarefas-count",
      data.stats?.[2]?.value ?? 0
    );

    setText(
      "xp-distribuido-count",
      data.stats?.[3]?.value ?? 0
    );

    // Lists
    renderTeachers(data.teachers || []);
    renderAlerts(data.alerts || []);
    renderClasses(data.classes || []);
    renderXpChart(data.xpChart || []);
    renderActivities(data.activities || []);

    // XP
    setText(
      "xp-month-value",
      data.xpMonthValue ?? "0"
    );

    setText(
      "xp-month-delta",
      data.xpMonthDelta ?? "—"
    );

  } catch (error) {
    console.error(
      " Erro fatal ao carregar dashboard:",
      error
    );
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadDashboard();
});